//
//  MLhelper.swift
//  MiniMel
//
//  Created by Melissa Adesina on 20/05/2025.
//

import UIKit
import CoreML
import Vision // Import Vision

func classifyImage(_ image: UIImage) -> (category: String, kind: String?, subkind: String?, style: String?) {
    guard let cgImage = image.cgImage else {
        print("❌ Could not get CGImage from UIImage")
        return ("Top", nil, nil, nil) // Fallback
    }

    // Load the Core ML model (category_1)
    let config = MLModelConfiguration()
    guard let coreMLModel = try? category_1(configuration: config).model else {
        print("❌ Could not load category_1 model")
        return ("Top", nil, nil, nil) // Fallback
    }

    // First, classify the category
    do {
        guard let pixelBuffer = image.toCVPixelBuffer() else {
            print("❌ Could not convert image to pixel buffer")
            return ("Top", nil, nil, nil)
        }
        let categoryPrediction = try coreMLModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
        if let categoryResult = categoryPrediction.featureValue(for: "target")?.stringValue {
            print("🎯 Category Model Result: \(categoryResult)")
            
            if categoryResult.lowercased() == "bottom" {
                guard let bottomKindModel = try? BottomKind_1(configuration: config).model else {
                    print("❌ Could not load BottomKind_1 model")
                    return (categoryResult, nil, nil, nil)
                }
                let bottomKindPrediction = try bottomKindModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
                if let bottomKindResult = bottomKindPrediction.featureValue(for: "target")?.stringValue {
                    let mappedKind = mapBottomKindToValidOption(bottomKindResult)
                    var subkind: String? = nil
                    if let kind = mappedKind {
                        subkind = classifyBottomSubkind(image: image, kind: kind, pixelBuffer: pixelBuffer, config: config)
                    }
                    let style = classifyBottomStyle(pixelBuffer: pixelBuffer, config: config)
                    return (categoryResult, mappedKind, subkind, style)
                }
            } else if categoryResult.lowercased() == "one piece" {
                var onePieceKind: String? = nil
                var onePieceSubkind: String? = nil
                var onePieceStyle: String? = nil

                if let kindModel = try? OnePieceKind_1(configuration: config).model {
                    let kindPrediction = try kindModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
                    if let kindResult = kindPrediction.featureValue(for: "target")?.stringValue {
                        onePieceKind = mapOnePieceKindToValidOption(kindResult)
                    }
                }
                if let determinedKind = onePieceKind, let subkindModel = try? OnePieceSubKind_1(configuration: config).model {
                    let subkindPrediction = try subkindModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
                    if let subkindResult = subkindPrediction.featureValue(for: "target")?.stringValue {
                        onePieceSubkind = mapOnePieceSubkindToValidOption(subkindResult, forKind: determinedKind)
                    }
                }
                if let styleModel = try? OnePieceStyle_1(configuration: config).model {
                     let stylePrediction = try styleModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
                     if let styleResult = stylePrediction.featureValue(for: "target")?.stringValue {
                         onePieceStyle = mapOnePieceStyleToValidOption(styleResult)
                     }
                }
                return (categoryResult, onePieceKind, onePieceSubkind, onePieceStyle)
            } else if categoryResult.lowercased() == "shoe" {
                var shoeKind: String? = nil
                var shoeSubkind: String? = nil
                var shoeStyle: String? = nil

                if let kindModel = try? ShoeKind_1(configuration: config).model {
                    let kindPrediction = try kindModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
                    if let kindResult = kindPrediction.featureValue(for: "target")?.stringValue {
                        print("🎯 ShoeKind Model Result: \(kindResult)")
                        shoeKind = mapShoeKindToValidOption(kindResult)
                        print("🎯 Mapped ShoeKind: \(shoeKind ?? "nil")")
                    }
                } else {
                    print("❌ Could not load ShoeKind_1 model")
                }

                if let subkindModel = try? ShoeSubKind_1(configuration: config).model {
                    let subkindPrediction = try subkindModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
                    if let subkindResult = subkindPrediction.featureValue(for: "target")?.stringValue {
                        print("🎯 ShoeSubKind Model Result: \(subkindResult)")
                        shoeSubkind = mapShoeSubkindToValidOption(subkindResult)
                        print("🎯 Mapped ShoeSubkind: \(shoeSubkind ?? "nil")")
                    }
                } else {
                    print("❌ Could not load ShoeSubKind_1 model")
                }
                
                if let styleModel = try? ShoeStyle_1(configuration: config).model {
                     let stylePrediction = try styleModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
                     if let styleResult = stylePrediction.featureValue(for: "target")?.stringValue {
                         print("🎯 ShoeStyle Model Result: \(styleResult)")
                         shoeStyle = mapShoeStyleToValidOption(styleResult)
                         print("🎯 Mapped ShoeStyle: \(shoeStyle ?? "nil")")
                     }
                } else {
                    print("❌ Could not load ShoeStyle_1 model")
                }

                return (categoryResult, shoeKind, shoeSubkind, shoeStyle)
            }
            
            return (categoryResult, nil, nil, nil)
        } else {
            print("❌ Could not get prediction result")
            return ("Top", nil, nil, nil)
        }
    } catch {
        print("❌ ML Classification failed: \(error)")
        return ("Top", nil, nil, nil)
    }
}

func classifyBottomStyle(pixelBuffer: CVPixelBuffer, config: MLModelConfiguration) -> String? {
    do {
        guard let bottomStyleModel = try? BottomStyle(configuration: config).model else {
            print("❌ Could not load BottomStyle model")
            return nil
        }
        
        let stylePrediction = try bottomStyleModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
        if let styleResult = stylePrediction.featureValue(for: "target")?.stringValue {
            print("🎯 BottomStyle Model Result: \(styleResult)")
            return mapBottomStyleToValidOption(styleResult)
        }
    } catch {
        print("❌ Bottom style classification failed: \(error)")
    }
    
    return nil
}

func mapBottomStyleToValidOption(_ mlResult: String) -> String? {
    let lowercased = mlResult.lowercased()
    if lowercased.contains("low") {
        return "Low-Rise"
    } else if lowercased.contains("mid") {
        return "Mid-Rise"
    } else if lowercased.contains("high") {
        return "High-Rise"
    }
    return nil
}

func classifyBottomSubkind(image: UIImage, kind: String, pixelBuffer: CVPixelBuffer, config: MLModelConfiguration) -> String? {
    do {
        if kind == "Jeans:Trousers" {
            guard let jeansModel = try? BottomSubKind_jeans__1(configuration: config).model else {
                print("❌ Could not load BottomSubKind(jeans) 1 model")
                return nil
            }
            
            let jeansPrediction = try jeansModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
            if let jeansResult = jeansPrediction.featureValue(for: "target")?.stringValue {
                print("🎯 Jeans Subkind Model Result: \(jeansResult)")
                return mapJeansSubkindToValidOption(jeansResult)
            }
            
        } else if kind.contains("Skirt") {
            guard let skirtModel = try? BottomSubKind_Skirt__1(configuration: config).model else {
                print("❌ Could not load BottomSubKind(Skirt) 1 model")
                return nil
            }
            
            let skirtPrediction = try skirtModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
            if let skirtResult = skirtPrediction.featureValue(for: "target")?.stringValue {
                print("🎯 Skirt Subkind Model Result: \(skirtResult)")
                return mapSkirtSubkindToValidOption(skirtResult)
            }
            
        } else if kind.contains("Shorts") {
            guard let shortsModel = try? BottomSubKind_Shorts__1(configuration: config).model else {
                print("❌ Could not load BottomSubKind(Shorts) 1 model")
                return nil
            }
            
            let shortsPrediction = try shortsModel.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]))
            if let shortsResult = shortsPrediction.featureValue(for: "target")?.stringValue {
                print("🎯 Shorts Subkind Model Result: \(shortsResult)")
                return mapShortsSubkindToValidOption(shortsResult)
            }
        }
    } catch {
        print("❌ Subkind classification failed: \(error)")
    }
    
    return nil
}

func mapBottomKindToValidOption(_ mlResult: String) -> String? {
    let lowercased = mlResult.lowercased()
    if lowercased.contains("jean") || lowercased.contains("trouser") || lowercased.contains("pant") {
        return "Jeans:Trousers"
    } else if lowercased.contains("skirt") {
        return "Mini Skirt"
    } else if lowercased.contains("short") {
        return "Mini Shorts"
    }
    
    return nil 
}

func mapJeansSubkindToValidOption(_ mlResult: String) -> String? {
    let lowercased = mlResult.lowercased()
    if lowercased.contains("skinny") {
        return "Skinny"
    } else if lowercased.contains("bootcut") {
        return "Bootcut"
    } else if lowercased.contains("straight") {
        return "Straight Leg"
    } else if lowercased.contains("wide") {
        return "Wide Leg"
    }
    return nil
}

func mapSkirtSubkindToValidOption(_ mlResult: String) -> String? {
    let lowercased = mlResult.lowercased()
    if lowercased.contains("bubble") {
        return "Bubble"
    } else if lowercased.contains("pleated") {
        return "Pleated"
    } else if lowercased.contains("flared") {
        return "Flared"
    } else if lowercased.contains("frill") {
        return "Frill"
    }
    return nil
}

func mapShortsSubkindToValidOption(_ mlResult: String) -> String? {
    let lowercased = mlResult.lowercased()
    if lowercased.contains("jort") {
        return "Jorts"
    } else if lowercased.contains("capri") {
        return "Capris"
    } else if lowercased.contains("tailored") {
        return "tailored"
    }
    return nil
}

func mapOnePieceKindToValidOption(_ mlResult: String) -> String? {
    let lowercasedResult = mlResult.lowercased()
    if lowercasedResult.contains("mini") && lowercasedResult.contains("dress") { return "Mini Dress" }
    if lowercasedResult.contains("midi") && lowercasedResult.contains("dress") { return "Midi Dress" }
    if lowercasedResult.contains("maxi") && lowercasedResult.contains("dress") { return "Maxi Dress" }
    if lowercasedResult.contains("high") && lowercasedResult.contains("low") && lowercasedResult.contains("dress") { return "High-Low Dress" }
    if lowercasedResult.contains("dress") { return "Mini Dress" } 
    return nil
}

func mapOnePieceSubkindToValidOption(_ mlResult: String, forKind: String) -> String? {
    let lowercasedResult = mlResult.lowercased()
    let validSubkindsForKind = ["Tulle Skirt", "A-line", "Bodycon", "Frill", "Bubble"]
    for subkindOption in validSubkindsForKind {
        if lowercasedResult.contains(subkindOption.lowercased()) {
            return subkindOption
        }
    }
    if lowercasedResult.contains("tulle") { return "Tulle Skirt" }
    if lowercasedResult.contains("a-line") || lowercasedResult.contains("aline") { return "A-line" }
    if lowercasedResult.contains("bodycon") { return "Bodycon" }
    if lowercasedResult.contains("frill") { return "Frill" }
    if lowercasedResult.contains("bubble") { return "Bubble" }
    return nil
}

func mapOnePieceStyleToValidOption(_ mlResult: String) -> String? {
    let lowercasedResult = mlResult.lowercased()
    if lowercasedResult.contains("square") && lowercasedResult.contains("neck") { return "Square Neck" }
    if lowercasedResult.contains("round") && lowercasedResult.contains("neck") { return "Round Neck" }
    if lowercasedResult.contains("high") && lowercasedResult.contains("neck") { return "High Neck" }
    if lowercasedResult.contains("bandeau") { return "Bandeau" }
    if lowercasedResult.contains("one") && lowercasedResult.contains("shoulder") { return "One Shoulder" }
    return nil
}

func mapShoeKindToValidOption(_ mlResult: String) -> String? {
    let lowercasedResult = mlResult.lowercased()
    if lowercasedResult.contains("open") && (lowercasedResult.contains("toe") || lowercasedResult.contains("shoe")) { return "Open-toe Shoe" }
    if lowercasedResult.contains("closed") && (lowercasedResult.contains("toe") || lowercasedResult.contains("shoe")) { return "Closed-toe Shoe" }
    if lowercasedResult.contains("shoe") { return "Open-toe Shoe" } 
    return nil
}

func mapShoeSubkindToValidOption(_ mlResult: String) -> String? {
    let lowercasedResult = mlResult.lowercased()
    let subkindOptions = ["Boots", "Strap Up", "Mules", "Trainers", "Loafers", "Ankle-strap"]
    for subkindOption in subkindOptions {
        if lowercasedResult.contains(subkindOption.lowercased().replacingOccurrences(of: "-", with: " ")) { 
            return subkindOption
        }
    }
    if lowercasedResult.contains("boot") { return "Boots" }
    if lowercasedResult.contains("trainer") || lowercasedResult.contains("sneaker") { return "Trainers" }
    if lowercasedResult.contains("loafer") { return "Loafers" }
    if lowercasedResult.contains("mule") { return "Mules" }
    if lowercasedResult.contains("strap") { return "Strap Up"} 
    return nil
}

func mapShoeStyleToValidOption(_ mlResult: String) -> String? {
    let lowercasedResult = mlResult.lowercased()
    if lowercasedResult.contains("round") { return "Round" }
    if lowercasedResult.contains("point") { return "Pointed" } 
    if lowercasedResult.contains("square") { return "Square" }
    return nil
}

extension UIImage {
    func toCVPixelBuffer() -> CVPixelBuffer? {
        guard let cgImage = self.cgImage else { return nil }
        
        let targetSize = CGSize(width: 299, height: 299) 
        let attrs = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue!
        ] as CFDictionary
        
        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            Int(targetSize.width),
            Int(targetSize.height),
            kCVPixelFormatType_32ARGB,
            attrs,
            &pixelBuffer
        )
        
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else { return nil }
        
        CVPixelBufferLockBaseAddress(buffer, CVPixelBufferLockFlags(rawValue: 0))
        defer { CVPixelBufferUnlockBaseAddress(buffer, CVPixelBufferLockFlags(rawValue: 0)) }
        
        let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: Int(targetSize.width),
            height: Int(targetSize.height),
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue
        )
        
        context?.translateBy(x: 0, y: targetSize.height)
        context?.scaleBy(x: 1, y: -1)
        context?.draw(cgImage, in: CGRect(origin: .zero, size: targetSize))
        
        return buffer
    }
}

extension CGImagePropertyOrientation {
    init(_ uiOrientation: UIImage.Orientation) {
        switch uiOrientation {
            case .up: self = .up
            case .down: self = .down
            case .left: self = .left
            case .right: self = .right
            case .upMirrored: self = .upMirrored
            case .downMirrored: self = .downMirrored
            case .leftMirrored: self = .leftMirrored
            case .rightMirrored: self = .rightMirrored
            @unknown default: self = .up
        }
    }
}
