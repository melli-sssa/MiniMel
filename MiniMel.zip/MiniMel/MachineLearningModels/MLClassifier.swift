//
//  MLClassifier.swift
//  MiniMel
//
//  Created by Melissa Adesina on 20/05/2025.
//

import UIKit
import Vision
import CoreML

final class MLClassifier {
  static let shared = MLClassifier()
  
  private init() {}
}
