//
//  MiniMelUITests.swift
//  MiniMelUITests
//
//  Created by Melissa Adesina on 04/03/2025.
//

import XCTest

final class MiniMelUITests: XCTestCase {
    
    var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        app = XCUIApplication()
        app.launchArguments = ["UI_TESTING"]
        app.launch()
    }

    override func tearDownWithError() throws {
        app = nil
    }

    // MARK: - Authentication Tests
    
    @MainActor
    func testAppLaunchShowsAuthView() throws {
        // Wait for the app to load
        let loginText = app.staticTexts["Login"]
        XCTAssertTrue(loginText.waitForExistence(timeout: 5), "Login title should be visible on app launch")
        
        // Check for  auth elements
        XCTAssertTrue(app.textFields["Email"].exists, "Email field should be present")
        XCTAssertTrue(app.secureTextFields["Password"].exists, "Password field should be present")
        XCTAssertTrue(app.buttons["Submit"].exists, "Submit button should be present")
        XCTAssertTrue(app.buttons["Sign Up"].exists, "Sign Up button should be present")
    }
    
    @MainActor
    func testNavigateToSignUpView() throws {
        // Wait for login view to load first
        XCTAssertTrue(app.staticTexts["Login"].waitForExistence(timeout: 5), "Login view should load")
        
        // Tap on Sign Up button
        app.buttons["Sign Up"].tap()
        
        // Wait for sign up view to appear
        let signUpText = app.staticTexts["Sign Up"]
        XCTAssertTrue(signUpText.waitForExistence(timeout: 3), "Sign Up title should be visible")
        
        // Verify Sign Up view elements
        XCTAssertTrue(app.textFields["Name"].exists, "Name field should be present")
        XCTAssertTrue(app.textFields["Surname"].exists, "Surname field should be present")
        XCTAssertTrue(app.textFields["Email"].exists, "Email field should be present")
        XCTAssertTrue(app.secureTextFields["Password"].exists, "Password field should be present")
        XCTAssertTrue(app.secureTextFields["Confirm Password"].exists, "Confirm Password field should be present")
        XCTAssertTrue(app.buttons["Submit"].exists, "Submit button should be present")
        XCTAssertTrue(app.buttons["Back"].exists, "Back button should be present")
    }
    
    @MainActor
    func testBackButtonFromSignUpView() throws {
        // Navigate to Sign Up
        XCTAssertTrue(app.staticTexts["Login"].waitForExistence(timeout: 5), "Login view should load")
        app.buttons["Sign Up"].tap()
        XCTAssertTrue(app.staticTexts["Sign Up"].waitForExistence(timeout: 3), "Should navigate to Sign Up")
        
        // Tap Back button
        app.buttons["Back"].tap()
        
        // Verify  back to login view
        XCTAssertTrue(app.staticTexts["Login"].waitForExistence(timeout: 3), "Should return to Login view")
        XCTAssertTrue(app.buttons["Sign Up"].exists, "Sign Up button should be visible again")
    }
    
    @MainActor
    func testPasswordMismatchWarning() throws {
        // Navigate to Sign Up
        XCTAssertTrue(app.staticTexts["Login"].waitForExistence(timeout: 5), "Login view should load")
        app.buttons["Sign Up"].tap()
        XCTAssertTrue(app.staticTexts["Sign Up"].waitForExistence(timeout: 3), "Should navigate to Sign Up")
        
        // Fill in passwords that don't match
        let passwordField = app.secureTextFields["Password"]
        passwordField.tap()
        passwordField.typeText("password123")
        
        let confirmPasswordField = app.secureTextFields["Confirm Password"]
        confirmPasswordField.tap()
        confirmPasswordField.typeText("differentpassword")
        
        // Tap somewhere else to trigger validation
        app.textFields["Name"].tap()
        
        // Wait for warning message and verify it appears
        let warningText = app.staticTexts["⚠️ Passwords do not match"]
        XCTAssertTrue(warningText.waitForExistence(timeout: 2), "Password mismatch warning should appear")
    }
    
    @MainActor
    func testFormFieldsExist() throws {
        // Test login form
        XCTAssertTrue(app.staticTexts["Login"].waitForExistence(timeout: 5), "Login view should load")
        
        let emailField = app.textFields["Email"]
        let passwordField = app.secureTextFields["Password"]
        let submitButton = app.buttons["Submit"]
        
        XCTAssertTrue(emailField.exists, "Email field should exist")
        XCTAssertTrue(passwordField.exists, "Password field should exist")
        XCTAssertTrue(submitButton.exists, "Submit button should exist")
        
        // Test that fields are interactive
        emailField.tap()
        emailField.typeText("test@example.com")
        
        passwordField.tap()
        passwordField.typeText("testpassword")
        
        // Verify text was entered (we can't read secure field text, but we can verify it accepted input)
        XCTAssertEqual(emailField.value as? String, "test@example.com", "Email field should accept text input")
    }

    // MARK: - Performance Tests
    
    @MainActor
    func testLaunchPerformance() throws {
        if #available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 7.0, *) {
            // This measures how long it takes to launch your application.
            measure(metrics: [XCTApplicationLaunchMetric()]) {
                XCUIApplication().launch()
            }
        }
    }
    
    // MARK: - Accessibility Tests
    
    @MainActor 
    func testAccessibilityLabels() throws {
        // Wait for app to load
        XCTAssertTrue(app.staticTexts["Login"].waitForExistence(timeout: 5), "Login view should load")
        
        // Test that important UI elements have proper accessibility
        XCTAssertTrue(app.textFields["Email"].exists, "Email field should have accessibility label")
        XCTAssertTrue(app.secureTextFields["Password"].exists, "Password field should have accessibility label") 
        XCTAssertTrue(app.buttons["Submit"].exists, "Submit button should have accessibility label")
        XCTAssertTrue(app.buttons["Sign Up"].exists, "Sign Up button should have accessibility label")
    }
    
    // MARK: - Basic Interaction Tests
    
    @MainActor
    func testBasicUserFlow() throws {
        // Test basic navigation flow without authentication
        XCTAssertTrue(app.staticTexts["Login"].waitForExistence(timeout: 5), "Login view should load")
        
        // Go to sign up
        app.buttons["Sign Up"].tap()
        XCTAssertTrue(app.staticTexts["Sign Up"].waitForExistence(timeout: 3), "Should navigate to Sign Up")
        
        // Fill out some fields
        app.textFields["Name"].tap()
        app.textFields["Name"].typeText("John")
        
        app.textFields["Surname"].tap()
        app.textFields["Surname"].typeText("Doe")
        
        // Go back to login
        app.buttons["Back"].tap()
        XCTAssertTrue(app.staticTexts["Login"].waitForExistence(timeout: 3), "Should return to Login")
        
        // Try to interact with login fields
        app.textFields["Email"].tap()
        app.textFields["Email"].typeText("john.doe@example.com")
        
        // This completes a basic user interaction flow
        XCTAssertEqual(app.textFields["Email"].value as? String, "john.doe@example.com", "Email should be entered correctly")
    }
}
