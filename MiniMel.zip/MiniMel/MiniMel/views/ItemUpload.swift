//
//  ItemUpload.swift
//  MiniMel
//
//  Created by Melissa Adesina on 18/03/2025.
//
import SwiftUI
import PhotosUI

struct ItemUploadView: View {
    @Binding var isUploadPopupVisible: Bool
    @ObservedObject var viewModel: ItemUploadViewModel

    var body: some View {
        ZStack {
            Color.black.opacity(0.5)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                Spacer()
                
                VStack(spacing: 20) {
                    Text("Upload Item")
                        .font(.headline)
                    
                    Button("Use Camera") {
                        // Future: implement camera logic
                    }
                    
                    PhotosPicker(
                        selection: $viewModel.selectedItem,
                        matching: .images,
                        photoLibrary: .shared()
                    ) {
                        Text("From Photo Album")
                    }
                    .onChange(of: viewModel.selectedItem) { oldItem, newItem in
                        guard let item = newItem else { return }
                        viewModel.handlePhotoPickerSelection(item: item)
                        isUploadPopupVisible = false
                    }
                    
                    
                    Button("Cancel") {
                        isUploadPopupVisible = false
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 20)
                .padding()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            

        }
    }
}
