//
//  AddDetailsView.swift
//  MiniMel
//
//  Created by Melissa Adesina on 19/03/2025.
//

import SwiftUI

struct AddDetailsView: View {
    @ObservedObject var viewModel: AddDetailsViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            // MARK: – Main form
            Group {
                if viewModel.classificationFailed {
                    // Fallback: ML failed, show manual pick
                    DropdownListView(viewModel: viewModel)
                } else {
                    // Normal flow (page 1→2→3)
                    GeometryReader { geo in
                        VStack(spacing: 0) {
                            // Top Image (45%) with blur background
                            ZStack {
                                Color.black.opacity(0.1)
                                    .ignoresSafeArea()
                                
                                Rectangle()
                                    .fill(.ultraThinMaterial)
                                    .blur(radius: 2)
                                    .ignoresSafeArea()
                                
                                TopImageSection(image: viewModel.selectedImage)
                            }
                            .frame(height: geo.size.height * 0.45)

                            // Bottom Details (55%)
                            BottomDetailsSection(viewModel: viewModel)
                                .frame(height: geo.size.height * 0.55)
                        }
                    }
                }
            }

            // MARK: – Full-screen ML spinner overlay
            if viewModel.isClassifying {
                VStack(spacing: 16) {
                    ProgressView().scaleEffect(1.5)
                    Text("AI Tagging taking place…")
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black.opacity(0.4))
            }
        }
        .edgesIgnoringSafeArea(.all)
       
    }
}
    
    
    struct TopImageSection: View {
        let image: UIImage?
        
        var body: some View {
            Group {
                if let ui = image {
                    Image(uiImage: ui)
                        .resizable()
                        .scaledToFit()
                } else {
                    Color(.systemGray5)
                        .overlay(Text("No Image").foregroundColor(.gray))
                }
            }
            .frame(maxWidth: .infinity)
            .clipped()
        }
    }
    
    struct BottomDetailsSection: View {
        @ObservedObject var viewModel: AddDetailsViewModel
        @Environment(\.dismiss) private var dismiss
        
        
        var body: some View {
            ZStack(alignment: .top) {
                if viewModel.currentPage < 3 {
                    DropdownListView(viewModel: viewModel)
                } else {
                    OccasionsGridView(
                        viewModel: viewModel,
                        occasions:   viewModel.occasions,
                        selectedSet: $viewModel.selectedOccasions,
                        isSubmitting: viewModel.isSubmitting,
                        onSubmit:   {
                            Task {
                                await viewModel.submit()
                                dismiss()
                            }
                        }
                    )
                }
                
                Rectangle()
                    .fill(Color.pink)
                    .frame(height: 2)
                    .frame(maxWidth: .infinity)
                
                HStack {
                    PinkBackButton { viewModel.goBack() }
                        .frame(width: 24, height: 24)
                    Spacer()
                    PinkForwardButton { viewModel.goForward() }
                        .frame(width: 24, height: 24)
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
            }
            .background(Color(.systemBackground))
        }
    }
    
    // ────────────────────────────────────────────────────────────────
    // MARK: OccasionsGridView (Page 3)
    // ────────────────────────────────────────────────────────────────
    
    struct OccasionsGridView: View {
        @ObservedObject var viewModel: AddDetailsViewModel
        let occasions: [OccasionOption]
        @Binding var selectedSet: Set<String>
        let isSubmitting: Bool
        let onSubmit: () -> Void
        @State private var showIncompleteAlert = false
        
        
        private let columns = Array(repeating: GridItem(.flexible(), spacing: 16), count: 3)
        
        var body: some View {
            VStack(spacing: 16) {
                Spacer().frame(height: 40)
                
                Text("what occasions can this be worn for?\n(tick all that apply)")
                    .font(.system(.headline, design: .monospaced))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Spacer()
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(occasions, id: \.name) { occ in
                            VStack(spacing: 8) {
                                PinkCheckbox(
                                    isChecked: Binding(
                                        get:  { selectedSet.contains(occ.name) },
                                        set: { on in
                                            if on { selectedSet.insert(occ.name) }
                                            else  { selectedSet.remove(occ.name) }
                                        }
                                    )
                                )
                                Text(occ.name)
                                    .font(.system(.caption2, design: .monospaced))
                                    .fontWeight(.bold)
                                    .multilineTextAlignment(.center)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            .frame(maxWidth: .infinity)
                        }
                    }
                    .padding(.horizontal, 16)
                }
                
                Spacer()
                
                SubmitButton {
                    if viewModel.canSubmit {
                        onSubmit()
                    } else {
                        showIncompleteAlert = true
                    }
                }
                .disabled(isSubmitting)    // still prevent double‐taps while uploading
                .padding(.horizontal, 32)
                .padding(.bottom, 24)
                .alert("Please complete all fields before submitting", isPresented: $showIncompleteAlert) {
                    Button("OK", role: .cancel) { }
                }
                
                if isSubmitting {
                    ProgressView("Uploading…")
                        .padding(.bottom, 16)
                }
                
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        }
    }
    
    // ────────────────────────────────────────────────────────────────
    // MARK: DropdownListView (Pages 1 & 2)
    // ────────────────────────────────────────────────────────────────
    
    struct DropdownRowView: View {
        @Binding var selection: String?
        @Binding var isExpanded: Bool
        let placeholder: String
        let options: [String]
        
        var body: some View {
            CustomDropdown(
                selection:   $selection,
                isExpanded:  $isExpanded,
                placeholder: placeholder,
                options:     options
            )
            .frame(maxWidth: .infinity)
        }
    }
    
struct DropdownListView: View {
    @ObservedObject var viewModel: AddDetailsViewModel
    
    var body: some View {
        VStack(spacing: 16) {
            Spacer().frame(height: 40)
            
            VStack(spacing: 8) {
                
                ForEach(viewModel.dropdownOptions.indices, id: \.self) { idx in
                    DropdownRowView(
                        // 1) bind via the new VM helper
                        selection:   viewModel.selectionBinding(at: idx),
                        
                        // 2) expansion logic unchanged
                        isExpanded:  Binding(
                            get:  { viewModel.expandedIndex == idx },
                            set: { open in viewModel.expandedIndex = open ? idx : nil }
                        ),
                        
                        // 3) placeholders come straight from the VM
                        placeholder: viewModel.currentPlaceholders[idx],
                        
                        // 4) options array unchanged
                        options:     viewModel.dropdownOptions[idx]
                    )
                }
                
                Spacer()
            }
            .padding(.horizontal, 16)
        }
    }
    
}
