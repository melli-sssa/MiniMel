import SwiftUI
import PhotosUI

struct WardrobeView: View {
    // MARK: - State & ViewModels
    @State private var showGenerator = false
    @StateObject private var uploadVM = ItemUploadViewModel()
    @EnvironmentObject var authVM: AuthViewModel
    @StateObject private var vm: WardrobeViewModel
    @State private var isFilterDropdownExpanded = false
    @State private var currentFilterSelectionForDropdown: String? = "All Categories"

    // MARK: - Layout constants
    private let palePink = Color(red: 1, green: 0.88, blue: 0.94)
    private let borderPink = Color.pink.opacity(0.6)
    private let backgroundPink = Color(red: 1.0, green: 0.95, blue: 0.97)
    private let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]

    // MARK: - Init
    init(userID: String) {
        _vm = StateObject(wrappedValue: WardrobeViewModel(userID: userID))
    }

    private var filterOptions: [String] {
        ["All Categories"] + vm.categories.map { $0.name }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                CustomDropdown(
                    selection: $currentFilterSelectionForDropdown,
                    isExpanded: $isFilterDropdownExpanded,
                    placeholder: "All Categories",
                    options: filterOptions
                )
                .onChange(of: currentFilterSelectionForDropdown) { oldValue, newValue in
                    if newValue == "All Categories" {
                        vm.selectCategory(nil)
                    } else if let selectedName = newValue,
                              let category = vm.categories.first(where: { $0.name == selectedName }) {
                        vm.selectCategory(category.id)
                    } else {
                        vm.selectCategory(nil)
                    }
                }
                
                Spacer()
                
                // FIX: '+' button stays in position when dropdown opens
                PhotosPicker(
                    selection: $uploadVM.selectedItem,
                    matching: .images,
                    photoLibrary: .shared()
                ) {
                    Image(systemName: "plus")
                        .font(.system(size: 18, weight: .medium)) 
                        .foregroundColor(.black)
                        .padding(10) 
                        .background(Color(red: 1.0, green: 0.88, blue: 0.94)) 
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.black, lineWidth: 2))
                        .shadow(color: Color.black.opacity(0.2), radius: 4, x: 0, y: 2)
                }
                .zIndex(1) 
                .onChange(of: uploadVM.selectedItem) { oldValue, newValue in
                    if let item = newValue {
                        uploadVM.handlePhotoPickerSelection(item: item)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            
            if vm.items.isEmpty {
                Text("Add items to your wardrobe now")
                    .foregroundColor(.gray)
                    .padding()
            } else {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(vm.items) { item in
                            WardrobeItemView(
                                item: item,
                                isSelected: false,
                                borderColor: borderPink,
                                onDelete: {
                                    Task {
                                        await vm.deleteItem(item)
                                    }
                                }
                            )
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 20)
                }
            }
        }
        .navigationDestination(isPresented: $showGenerator) {
            if let userID = authVM.userID?.uuidString {
                GenerateOutfitView(userID: userID)
            } else {
                Text("Error: User ID not available.")
                    .foregroundColor(.red)
                    .onAppear {
                        print("⚠️ WardrobeView: Attempted to navigate to GenerateOutfitView, but authVM.userID was nil.")
                    }
            }
        }
        .sheet(
            isPresented: $uploadVM.shouldNavigateToDetails,
            onDismiss: {
                if let uuid = authVM.userID {
                    Task { await vm.loadItems(for: uuid.uuidString) }
                }
            }
        ) {
            if let img = uploadVM.selectedImage,
               let uuid = authVM.userID {
                AddDetailsView(
                    viewModel: AddDetailsViewModel(
                        initialImage: img,
                        userID: uuid.uuidString
                    )
                )
            } else {
                Text("Couldn't load form.")
            }
        }
        .onAppear {
            if vm.selectedCategoryID == nil {
                currentFilterSelectionForDropdown = "All Categories"
            } else if let category = vm.categories.first(where: { $0.id == vm.selectedCategoryID }) {
                currentFilterSelectionForDropdown = category.name
            }
        }
    }
}

// MARK: - Item Cell
struct WardrobeItemView: View {
    let item: ClothingItem
    let isSelected: Bool
    let borderColor: Color
    var onDelete: () -> Void

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            // Image Display Area
            AsyncImage(url: item.imageURL) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .frame(height: 160)
                        .frame(maxWidth: .infinity)
                case .success(let img):
                    img
                        .resizable()
                        .scaledToFit()
                        .frame(height: 160)
                        .frame(maxWidth: .infinity)
                        .clipped()
                case .failure:
                    Image(systemName: "photo.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60, height: 60)
                        .foregroundColor(.gray.opacity(0.6))
                        .frame(height: 160)
                        .frame(maxWidth: .infinity)
                @unknown default:
                    EmptyView()
                        .frame(height: 160)
                        .frame(maxWidth: .infinity)
                }
            }
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.black, lineWidth: 2)
            )
            .shadow(color: Color(red: 1.0, green: 0.88, blue: 0.94).opacity(0.4), radius: 4, x: 0, y: 2)

            // Delete button
            Button(action: onDelete) {
                Image(systemName: "trash.fill")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.black) 
                    .padding(8)
                    .background(Color(red: 1.0, green: 0.88, blue: 0.94)) 
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.black, lineWidth: 1)) 
                    .shadow(color: Color.black.opacity(0.25), radius: 3, x: 0, y: 1)
            }
            .padding(6)
        }
    }
}
