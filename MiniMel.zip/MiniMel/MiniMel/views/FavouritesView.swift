//
//  FavouritesView.swift
//  MiniMel
//
//  Created by Melissa Adesina on 15/05/2025.
//

import SwiftUI

struct FavoritesView: View {
    @StateObject private var viewModel: FavoritesViewModel
    
    init(userID: String) {
        _viewModel = StateObject(wrappedValue: FavoritesViewModel(userID: userID))
    }

    var body: some View {
        ScrollView {
            if viewModel.outfits.isEmpty {
                VStack {
                    Spacer()
                    Text("No saved outfits yet.")
                        .foregroundColor(.gray)
                        .padding()
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                LazyVStack(spacing: 20) {
                    ForEach(viewModel.outfits) { outfit in
                        outfitCard(for: outfit)
                    }
                }
                .padding(16)
            }
        }
        .onAppear {
            Task {
                await viewModel.fetchSavedOutfits()
            }
        }
    }
   
    @ViewBuilder
    private func outfitCard(for outfit: FavoritesViewModel.OutfitDisplay) -> some View {
        ZStack(alignment: .bottomLeading) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) { 
                    if let one = outfit.onePiece {
                        HStack {
                            Spacer()
                            GeneratedOutfitDisplay(item: one, label: "Dress", showShadow: false, imageMaxHeight: 150) 
                                .frame(width: 130) 
                            if let shoe = outfit.shoe {
                                GeneratedOutfitDisplay(item: shoe, label: "Shoes", showShadow: false, imageMaxHeight: 150) 
                                    .frame(width: 130) 
                            }
                            Spacer()
                        }
                    } else {
                        if let top = outfit.top {
                            GeneratedOutfitDisplay(item: top, label: "Top", showShadow: false, imageMaxHeight: 130)
                                .frame(width: 115)
                        }
                        if let bottom = outfit.bottom {
                            GeneratedOutfitDisplay(item: bottom, label: "Bottom", showShadow: false, imageMaxHeight: 130)
                                .frame(width: 115)
                        }
                        if let shoe = outfit.shoe {
                            GeneratedOutfitDisplay(item: shoe, label: "Shoes", showShadow: false, imageMaxHeight: 130)
                                .frame(width: 115)
                        }
                    }
                }
                .padding(.horizontal, 16) 
            }
            .frame(height: 160) 

            Button {
                Task {
                    await viewModel.deleteSavedOutfit(outfitIdToDelete: outfit.id)
                }
            } label: {
                Image(systemName: "trash.fill")
                    .font(.caption)
                    .foregroundColor(.black)
                    .padding(8)
                    .background(Color(red: 1.0, green: 0.88, blue: 0.94))
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.black, lineWidth: 1))
                    .shadow(radius: 2)
            }
            .padding(8)
        }
        .frame(maxWidth: .infinity, maxHeight: 180) 
        .background(RoundedRectangle(cornerRadius: 16).fill(Color.clear))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.black, lineWidth: 2))
        .shadow(color: Color(red: 1.0, green: 0.88, blue: 0.94).opacity(0.3), radius: 6, x: 0, y: 3)
    }
}
