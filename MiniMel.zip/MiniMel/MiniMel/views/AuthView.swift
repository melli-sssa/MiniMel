import SwiftUI
import WebKit

struct AnimatedGIFView: UIViewRepresentable {
    let gifName: String
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.backgroundColor = UIColor.clear
        webView.isOpaque = false
        webView.scrollView.isScrollEnabled = false
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        guard let gifPath = Bundle.main.path(forResource: gifName, ofType: "gif"),
              let gifData = NSData(contentsOfFile: gifPath) else {
            return
        }
        
        let html = """
        <html>
        <head>
            <style>
                body { margin: 0; padding: 0; background: transparent; display: flex; justify-content: center; align-items: center; height: 100vh; }
                img { max-width: 100%; max-height: 100%; }
            </style>
        </head>
        <body>
            <img src="data:image/gif;base64,\(gifData.base64EncodedString())" />
        </body>
        </html>
        """
        
        webView.loadHTMLString(html, baseURL: nil)
    }
}

struct AuthView: View {
  // MARK: – State & ViewModel
  @StateObject private var authViewModel = AuthViewModel()
  @State private var isSigningUp = false
  @State private var isLoggedIn  = false
  @State private var activeTab: ActiveTab = .wardrobe

  // MARK: – Login Sub-view
  @ViewBuilder
  private var loginView: some View {
    VStack(spacing: 30) {
      Spacer()
      
      if let gifData = NSDataAsset(name: "Dress")?.data {
          ZStack {
              // Invisible container for positioning
              Rectangle()
                  .fill(Color.clear)
                  .frame(width: 200, height: 160)
              
              // GIF positioned within the container, moved 15px more to the left
              HStack {
                  WebView(data: gifData)
                      .frame(width: 160, height: 160)
                      .clipped()
                  Spacer()
              }
              .frame(width: 200) // Match container width
              .offset(x: -15)
          }
          .padding(.bottom, 20)
      } else {
          // Fallback: simple placeholder
          Circle()
              .fill(Color.pink.opacity(0.3))
              .frame(width: 120, height: 120)
              .overlay(
                  Text("👗")
                      .font(.system(size: 50))
              )
              .padding(.bottom, 20)
      }
      
      Text("Login")
        .font(.system(size: 32, weight: .bold, design: .monospaced))
        .foregroundColor(.black)
        .padding(.bottom, 30)

      VStack(spacing: 20) {
        TextField("Email", text: $authViewModel.email)
          .font(.system(.body, design: .monospaced))
          .padding()
          .background(Color(red: 1.0, green: 0.88, blue: 0.94).opacity(0.7))
          .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
          .cornerRadius(8)

        SecureField("Password", text: $authViewModel.password)
          .font(.system(.body, design: .monospaced))
          .padding()
          .background(Color(red: 1.0, green: 0.88, blue: 0.94).opacity(0.7))
          .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
          .cornerRadius(8)
      }

      if authViewModel.isLoading {
        ProgressView()
          .padding()
      }
      
      if let err = authViewModel.errorMessage {
        Text(err)
          .font(.system(.caption, design: .monospaced))
          .foregroundColor(.red)
          .padding()
      }

      Button("Submit") {
        Task {
          await authViewModel.login()
          if authViewModel.isAuthenticated {
            isLoggedIn = true
          }
        }
      }
      .font(.system(.body, design: .monospaced))
      .fontWeight(.bold)
      .disabled(authViewModel.isLoading)
      .padding()
      .frame(maxWidth: .infinity)
      .foregroundColor(.black)
      .overlay(RoundedRectangle(cornerRadius: 25).stroke(Color.black, lineWidth: 2))
      .cornerRadius(25)
      .padding(.top, 20)

      Button("Sign Up") {
        isSigningUp = true
      }
      .font(.system(.body, design: .monospaced))
      .fontWeight(.bold)
      .foregroundColor(.black)
      .padding(.top, 20)
      
      Spacer()
    }
    .padding(32)
  }

  // MARK: – Sign-Up Sub-view
  @ViewBuilder
  private var signUpView: some View {
    VStack(spacing: 0) {
      // Back Button -
      HStack {
        Button {
          isSigningUp = false
        } label: {
          HStack(spacing: 8) {
            Image(systemName: "arrow.left")
              .font(.system(size: 18, weight: .medium))
            Text("Back")
              .font(.system(.body, design: .monospaced))
              .fontWeight(.bold)
          }
          .foregroundColor(.black)
        }
        Spacer()
      }
      .padding(.horizontal, 32)
      .padding(.top, 20)
      
      Spacer(minLength: 40)

      Text("Sign Up")
        .font(.system(size: 32, weight: .bold, design: .monospaced))
        .foregroundColor(.black)
        .padding(.bottom, 30)

      VStack(spacing: 20) {
        TextField("Name", text: $authViewModel.name)
          .font(.system(.body, design: .monospaced))
          .padding()
          .background(Color(red: 1.0, green: 0.88, blue: 0.94).opacity(0.7))
          .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
          .cornerRadius(8)

        TextField("Surname", text: $authViewModel.lastName)
          .font(.system(.body, design: .monospaced))
          .padding()
          .background(Color(red: 1.0, green: 0.88, blue: 0.94).opacity(0.7))
          .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
          .cornerRadius(8)

        TextField("Email", text: $authViewModel.email)
          .font(.system(.body, design: .monospaced))
          .padding()
          .background(Color(red: 1.0, green: 0.88, blue: 0.94).opacity(0.7))
          .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
          .cornerRadius(8)

        SecureField("Password", text: $authViewModel.password)
          .font(.system(.body, design: .monospaced))
          .padding()
          .background(Color(red: 1.0, green: 0.88, blue: 0.94).opacity(0.7))
          .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
          .cornerRadius(8)

        SecureField("Confirm Password", text: $authViewModel.confirmPassword)
          .font(.system(.body, design: .monospaced))
          .padding()
          .background(Color(red: 1.0, green: 0.88, blue: 0.94).opacity(0.7))
          .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
          .cornerRadius(8)
      }
      .padding(.horizontal, 32)

      if !authViewModel.confirmPassword.isEmpty
        && authViewModel.confirmPassword != authViewModel.password
      {
        Text("⚠️ Passwords do not match")
          .font(.system(.caption, design: .monospaced))
          .foregroundColor(.red)
          .padding(.top, 10)
      }

      if let err = authViewModel.errorMessage {
        Text(err)
          .font(.system(.caption, design: .monospaced))
          .foregroundColor(.red)
          .padding(.top, 10)
      }

      Button {
        Task { await authViewModel.signUp() }
      } label: {
        if authViewModel.isLoading {
          ProgressView()
        } else {
          Text("Submit")
            .font(.system(.body, design: .monospaced))
            .fontWeight(.bold)
        }
      }
      .disabled(
        authViewModel.isLoading ||
        authViewModel.password != authViewModel.confirmPassword
      )
      .padding()
      .frame(maxWidth: .infinity)
      .foregroundColor(.black)
      .overlay(RoundedRectangle(cornerRadius: 25).stroke(Color.black, lineWidth: 2))
      .cornerRadius(25)
      .padding(.horizontal, 32)
      .padding(.top, 30)

      if authViewModel.isAuthenticated {
        Text("✅ Sign-up successful!")
          .font(.system(.caption, design: .monospaced))
          .foregroundColor(.green)
          .padding(.top, 15)
      }
      
      Spacer(minLength: 40)
    }
  }

  // MARK: – Main Body
    var body: some View {
        NavigationStack {
            if authViewModel.isAuthenticated, let uuid = authViewModel.userID {
                RootContainerView(userID: uuid.uuidString, activeTab: $activeTab)
                    .environmentObject(authViewModel)
            } else {
                ZStack {
                    // Grid background
                    Color.white.ignoresSafeArea(.all)
                    Image("Grid")
                        .resizable(resizingMode: .tile)
                        .opacity(0.12)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .ignoresSafeArea(.all)

                    VStack {
                        if isSigningUp {
                            signUpView
                        } else {
                            loginView
                        }
                    }
                }
            }
        }
    }
}

struct WebView: UIViewRepresentable {
    let data: Data
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.backgroundColor = UIColor.clear
        webView.isOpaque = false
        webView.scrollView.isScrollEnabled = false
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        let html = """
        <html>
        <body style="margin:0; background:transparent; display:flex; justify-content:center; align-items:center; height:100vh;">
            <img src="data:image/gif;base64,\(data.base64EncodedString())" style="max-width:100%; max-height:100%;" />
        </body>
        </html>
        """
        webView.loadHTMLString(html, baseURL: nil)
    }
}

#Preview {
    AuthView()
}
