//
//  GenerateOutfitView.swift
//  MiniMel
//
//  Created by Melissa Adesina on 13/05/2025.
//

import SwiftUI

struct GenerateOutfitView: View {
    @StateObject var viewModel: GenerateOutfitViewModel
    @State private var isFilterExpanded = false
    @State private var selectedOccasionName: String?

    init(userID: String) {
        _viewModel = StateObject(wrappedValue: .init(userID: userID))
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                filterMenu
                contentView
                actionButtons
            }
            .padding(16)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    // MARK: – Filter menu (using CustomDropdown)
    private var filterMenu: some View {
        CustomDropdown(
            selection: $selectedOccasionName,
            isExpanded: $isFilterExpanded,
            placeholder: "Filter Occasion",
            options: viewModel.occasions.map { $0.name }
        )
        .onChange(of: selectedOccasionName) { oldValue, newValue in
            if let newValue = newValue,
               let occasion = viewModel.occasions.first(where: { $0.name == newValue }) {
                Task { await viewModel.selectOccasion(occasion) }
            }
        }
    }

    // MARK: – Main content
    @ViewBuilder
    private var contentView: some View {
        if let msg = viewModel.errorMessage {
            errorView(message: msg)
        }
        else if let outfit = viewModel.currentOutfit {
            VStack(spacing: 16) {
                outfitView(outfit)
                
                if viewModel.isCurrentOutfitSaved {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                        Text("SAVED")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.black)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.green.opacity(0.1))
                    .cornerRadius(20)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.black, lineWidth: 1)
                    )
                }
            }
        }
        else {
            loadingView
        }
    }

    private func errorView(message: String) -> some View {
        VStack(spacing: 12) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.largeTitle)
                .foregroundColor(.orange)
            
            Text(message)
                .foregroundColor(.black)
                .font(.system(size: 14, weight: .bold))
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .padding()
        .background(Color.orange.opacity(0.1))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.black, lineWidth: 1)
        )
    }

    private var loadingView: some View {
        VStack(spacing: 16) {
            Text("Select an occasion to generate outfits")
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(.black)
        }
        .padding()
    }

    private func outfitView(_ outfit: Outfit) -> some View {
        VStack(spacing: 16) {
            if let one = outfit.onePiece {
                onePieceSection(one: one, shoe: outfit.shoe)
            }
            else if let top = outfit.top, let bottom = outfit.bottom {
                twoPieceSection(top: top, bottom: bottom, shoe: outfit.shoe)
            }
            
            if !viewModel.suggestionForOccasion.isEmpty {
                Text("💡 \(viewModel.suggestionForOccasion)")
                    .font(.system(size: 12, weight: .regular, design: .monospaced))
                    .foregroundColor(.black)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(16)
            }
        }
    }

    private func onePieceSection(one: WardrobeItemWithCategory,
                                 shoe: WardrobeItemWithCategory) -> some View {
        VStack(spacing: 12) {
            GeneratedOutfitDisplay(item: one, label: "One Piece")
            GeneratedOutfitDisplay(item: shoe, label: "Shoes")
        }
        .frame(maxWidth: .infinity)
        .frame(maxWidth: .infinity, alignment: .center)
    }

    private func twoPieceSection(top: WardrobeItemWithCategory,
                                 bottom: WardrobeItemWithCategory,
                                 shoe: WardrobeItemWithCategory) -> some View {
        VStack(spacing: 12) {
            GeneratedOutfitDisplay(item: top, label: "Top")
            GeneratedOutfitDisplay(item: bottom, label: "Bottom")
            GeneratedOutfitDisplay(item: shoe, label: "Shoes")
        }
        .frame(maxWidth: .infinity)
        .frame(maxWidth: .infinity, alignment: .center)
    }

    // MARK: – Actions
    private var actionButtons: some View {
        HStack(spacing: 12) {
            Button {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                    viewModel.shuffleOutfit()
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "shuffle")
                    Text("Shuffle")
                }
            }
            .buttonStyle(ModernButton(style: .secondary))

            Button {
                withAnimation(.easeInOut) {
                    viewModel.nextOutfit()
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "arrow.right")
                    Text("Next")
                }
            }
            .buttonStyle(ModernButton(style: .primary))

            Button {
                Task { await viewModel.saveCurrentOutfit() }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: viewModel.isCurrentOutfitSaved ? "checkmark" : "heart")
                    Text(viewModel.isCurrentOutfitSaved ? "Saved" : "Save")
                }
            }
            .buttonStyle(ModernButton(style: viewModel.isCurrentOutfitSaved ? .saved : .accent))
            .disabled(viewModel.isCurrentOutfitSaved)
        }
        .padding(.top, 8)
    }
}

// MARK: – Modern Button Style (with pink color scheme)
private struct ModernButton: ButtonStyle {
    enum Style {
        case primary, secondary, accent, saved
        
        var backgroundColor: Color {
            switch self {
            case .primary: return Color(red: 0.85, green: 0.4, blue: 0.6) // Muted pink
            case .secondary: return Color(red: 0.95, green: 0.85, blue: 0.9) // Light pink
            case .accent: return Color(red: 0.9, green: 0.2, blue: 0.5) // Vibrant pink
            case .saved: return Color(red: 0.85, green: 0.95, blue: 0.85) // Light green
            }
        }
        
        var foregroundColor: Color {
            return .black
        }
    }
    
    let style: Style
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 14, weight: .semibold, design: .monospaced))
            .padding(.horizontal, 18)
            .padding(.vertical, 14)
            .background(style.backgroundColor)
            .foregroundColor(style.foregroundColor)
            .cornerRadius(25)
            .overlay(
                RoundedRectangle(cornerRadius: 25)
                    .stroke(Color.black, lineWidth: 2)
            )
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .opacity(configuration.isPressed ? 0.8 : 1.0)
            .animation(.easeOut(duration: 0.15), value: configuration.isPressed)
            .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
    }
}
