//  ItemUploadRepository.swift
//  MiniMel
//
//  Created by Melissa Adesina on 01/04/2025.
//
// Repository.swift
// AddDetailsRepository.swift
import Foundation
import Supabase
import UIKit

struct WardrobeItemPayload: Codable {
  let wardrobe_item_id: String
  let user_id:          String
  let image:            String
  let kind_id:          String
  let subkind_id:       String
  let style_id:         String
  let primary_fabric_id:String
  let secondary_fabric_id:String
  let color_id:         String
}

extension WardrobeItemPayload: WardrobeItemRepresentable {
    var imageURL: String {
        return image
    }
}

protocol WardrobeRepository {
    func uploadImage(data: Data, fileName: String, userID: String) async throws -> String
    func createItem(_ item: WardrobeItemPayload) async throws
    func linkOccasions(_ occasionIDs: [String], forWardrobeItemID itemID: String) async throws
    func fetchItems(for userID: String,  categoryID: Int?) async throws -> [WardrobeItemPayload]
    func fetchCategories() async throws -> [WardrobeCategory]
    // func fetchSavedOutfits(for userID: String) async throws -> [SavedOutfit] // Already exists in implementation
    func deleteWardrobeItem(itemID: String, imageName: String) async throws
    func deleteSavedOutfit(outfitID: UUID) async throws
}


final class SupabaseWardrobeRepository: WardrobeRepository {
    private let client = SupabaseClientManager.shared.getClient()
    static let shared = SupabaseWardrobeRepository()
    
    func uploadImage(
        data: Data,
        fileName: String,
        userID: String
    ) async throws -> String {
        let storage = client.storage.from("wardrobe-images")
        
        
        let options = try FileOptions(
            contentType: "image/jpeg",
            metadata: ["user_id": AnyJSON(userID)]
        )
        
        
        try await storage.upload(
            fileName,     // path
            data: data,   // the Data blob
            options: options
        )
        
        // getPublicURL now throws, so mark with try
        let publicURL = try storage.getPublicURL(path: fileName)
        return publicURL.absoluteString
        
    }
    
    func createItem(_ item: WardrobeItemPayload) async throws {
        // throws automatically on failure
        _ = try await client
            .from("wardrobe")
            .insert(item)
            .execute()
    }
    
    func linkOccasions(
        _ occasionIDs: [String],
        forWardrobeItemID itemID: String
    ) async throws {
        let rows = occasionIDs.map { occID in
            [ "wardrobe_id": itemID,
              "occasion_id": occID ]
        }
        _ = try await client
            .from("wardrobe_occasion")
            .insert(rows)
            .execute()
    }
    
    @MainActor
    func fetchCategories() async throws -> [WardrobeCategory] {
        return try await client
        .from("category")
        .select("*")
        .execute()
        .value
    }
    // for displaying in wardrobe view
    @MainActor
    func fetchItems(
      for userID: String,
      categoryID: Int? = nil
    ) async throws -> [WardrobeItemPayload] {
      // 1) build up all your filters first
      var builder = client
        .from("wardrobe")
        .select("*, kind!inner(category_id)")
        .eq("user_id", value: userID)

      if let cat = categoryID {
        builder = builder.eq("kind.category_id", value: cat)
      }

      // 2) _then_ apply the sort and execute in one go
      let items: [WardrobeItemPayload] = try await builder
        .order("wardrobe_item_id", ascending: false)
        .execute()
        .value

      return items
    }

   
    func saveOutfit(_ outfit: SavedOutfit) async throws {
        try await client
          .from("saved_outfits")
          .insert(outfit)
          .execute()
      }
    
    
    func fetchSavedOutfits(for userID: String) async throws -> [SavedOutfit] {
        return try await client
            .from("saved_outfits")
            .select("*")
            .eq("user_id", value: userID) // Filter by user_id
            .order("saved_at", ascending: false) 
            .execute()
            .value
    }
   // creates maste list of occasions for the drop down
    @MainActor
    func fetchOccasions() async throws -> [OccasionRecord] {
        // tell PostgREST to decode into [OccasionRecord]
        let response: PostgrestResponse<[OccasionRecord]> = try await client
          .from("occasion")
          .select("occasion_id,name")
          .execute()

        return response.value
    }


    //load clothes that belong to the current user and are tagged with a specific occasion.
    @MainActor
    func fetchItemsForOccasion(
      userID: String,
      occasionID: UUID
    ) async throws -> [WardrobeItemWithCategory] {
      let response: PostgrestResponse<[WardrobeItemWithCategory]> = try await client
        .from("wardrobe")
        .select("*, kind(*,category(*)), wardrobe_occasion!inner(occasion_id)")
        .eq("user_id",                   value: userID)
        .eq("wardrobe_occasion.occasion_id", value: occasionID)
        .execute()

      return response.value
    }

    @MainActor
    func fetchItemsForOccasionWithDetails(
      userID: String,
      occasionID: UUID
    ) async throws -> [WardrobeItemWithFullDetails] {
      let response: PostgrestResponse<[WardrobeItemWithFullDetails]> = try await client
        .from("wardrobe")
        .select("""
          *, 
          kind(*, category(*)), 
          primary_fabric:fabric!primary_fabric_id(*),
          secondary_fabric:fabric!secondary_fabric_id(*),
          wardrobe_occasion!inner(occasion_id)
        """)
        .eq("user_id", value: userID)
        .eq("wardrobe_occasion.occasion_id", value: occasionID)
        .execute()

      return response.value
    }

    @MainActor
    func fetchItemsWithCategories(for userID: String) async throws -> [WardrobeItemWithCategory] {
        // 1) Declare the response as PostgrestResponse<[YourModel]>
        let response: PostgrestResponse<[WardrobeItemWithCategory]> = try await client
            .from("wardrobe")
            .select("*, kind(*, category(*))")
            .eq("user_id", value: userID)
            .execute()         // <-- plain execute()

        // 2) Pull out the decoded array
        return response.value
    }
    
    func deleteWardrobeItem(itemID: String, imageName: String) async throws {
        // Step 1: Delete the image from Supabase Storage
        let storage = client.storage.from("wardrobe-images")
        _ = try await storage.remove(paths: [imageName]) 

        // Step 2: Delete the item record from the "wardrobe" table
        _ = try await client
            .from("wardrobe")
            .delete()
            .eq("wardrobe_item_id", value: itemID)
            .execute()
        
        // Note: Consider deleting related entries in "wardrobe_occasion" table if your DB doesn't handle cascading deletes.
        // This might require another call or a database trigger/function. For simplicity here, we are not adding it.
        // Also, consider if this item is part of any `saved_outfits`. Deleting a wardrobe item might invalidate saved outfits.
        // This also requires careful handling (e.g., set related fields in saved_outfits to NULL, or delete the saved_outfit).
    }

    func deleteSavedOutfit(outfitID: UUID) async throws {
        _ = try await client
            .from("saved_outfits")
            .delete()
            .eq("outfit_id", value: outfitID) 
            .execute()
    }
   
}
