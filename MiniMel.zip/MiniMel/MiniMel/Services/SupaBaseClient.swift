
import Supabase
import Foundation

class SupabaseClientManager {
    static let shared = SupabaseClientManager()
 
    private let client: SupabaseClient
    // only one instance of the SupaBase client
    
    private init() {
        let supabaseURL = URL(string: "https://xjaqjyfiiimhttzmmiqz.supabase.co")!
        let supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhqYXFqeWZpaWltaHR0em1taXF6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzY5ODY4NDYsImV4cCI6MjA1MjU2Mjg0Nn0.M2zyr69jUy5i7F4LeRqNs-ZaSgtLwlJFF2t2zrUc09A"
        // actual connection to SupaBase
        self.client = SupabaseClient(supabaseURL: supabaseURL, supabaseKey: supabaseKey)
        
    }

    func getClient() -> SupabaseClient {
        return client
    }
}

