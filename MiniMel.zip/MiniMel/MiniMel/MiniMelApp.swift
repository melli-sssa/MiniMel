//
//  MiniMelApp.swift
//  MiniMel
//
//  Created by Melissa Adesina on 04/03/2025.
//
import SwiftUI

@main
struct MiniMelApp: App {
    @StateObject private var authVM = AuthViewModel()
    @State private var activeTab: ActiveTab = .wardrobe

    var body: some Scene {
        WindowGroup {
            if authVM.isAuthenticated, let uid = authVM.userID {
                RootContainerView(userID: uid.uuidString, activeTab: $activeTab)
                    .environmentObject(authVM)
            } else {
                AuthView()
                    .environmentObject(authVM)
            }
        }
    }
}
