//
//  AddDetailsModel.swift
//  MiniMel
//
//  Created by Melissa Adesina on 04/04/2025.
//

import Foundation

// MARK: - option defenition 
struct OptionItem: Identifiable, Hashable {
  let id:   UUID
  let name: String
}
// MARK: - Category Enum

/// The main clothing categories used across the app.
enum Category: String, CaseIterable {
    case top = "Top"
    case bottom = "Bottom"
    case shoe = "Shoe"
    case onePiece = "One Piece"
}

// MARK: - Shoe Options Model

/// A dedicated model for Shoe options, which use heel types instead of generic styles.
struct ShoeOptions {
    let kindOptions: [String]      // e.g., "Open-toe Shoe", "Closed-toe Shoe"
    let subkindOptions: [String]   // e.g., "Boots", "Strap Up", "Mules", etc.
    let styleOptions: [String]   // e.g , "pointed" , "round" , "Square"
  
}

/// An instance of ShoeOptions for the Shoe category.
let shoeOptions = ShoeOptions(
    kindOptions: ["Open-toe Shoe", "Closed-toe Shoe"],
    subkindOptions: ["Boots", "Strap Up", "Mules", "Trainers", "Loafers", "Ankle-strap"],
    styleOptions: ["Round", "Pointed", "Square"]
)

// MARK: - Bottom Options Model

/// A generic model for Bottom options (Tops, Bottoms, One-Piece can use a similar model).
struct BottomOptions {
    let kindOptions: [String]                // e.g., "Maxi Skirt", "Jeans/Trousers", etc.
    let subkindMapping: [String: [String]]     // Maps a type group (e.g., "Skirt") to its subkinds.
    let styleOptions: [String]                 // e.g., "Low-Rise", "Mid-Rise", "High-Rise"
}

/// Kind options for the Bottom category.
let bottomKindOptions = [
    "Maxi Skirt",
    "Mini Skirt",
    "Midi Skirt",
    "Jeans:Trousers",
    "Knee Shorts",
    "Mini Shorts"
]

/// Subkind options are mapped based on the type:
/// - If the kind contains "Skirt": use skirt subkinds.
/// - If the kind contains "Shorts": use shorts subkinds.
/// - "Jeans/Trousers" has its own subkinds.
let bottomSubkindMapping: [String: [String]] = [
    "Skirt": ["Bubble", "Pleated", "Flared", "Frill"],
    "Shorts": ["Jorts", "Capris", "tailored"],
    "Jeans/Trousers": ["Skinny", "Bootcut", "Straight Leg", "Wide Leg"]
]

/// Common style options for bottoms.
let bottomStyleOptions = ["Low-Rise", "Mid-Rise", "High-Rise"]

/// An instance of BottomOptions for the Bottom category.
let bottomOptions = BottomOptions(
    kindOptions: bottomKindOptions,
    subkindMapping: bottomSubkindMapping,
    styleOptions: bottomStyleOptions
)

// MARK: - One-Piece (Dress) Options Model

/// A generic model for clothing options where the final attribute is a style.
struct ClothingOptions {
    let kindOptions: [String]                // e.g., "Mini Dress", "Midi Dress", etc.
    let subkindMapping: [String: [String]]     // Maps each kind to its subkinds.
    let finalOptions: [String]                 // Final options, such as style options.
}

// Define subkind options specific to dresses.
let dressSubkinds = ["Tulle Skirt", "A-line", "Bodycon", "Frill", "Bubble"]

// Define style options common to dresses.
let dressStyles = ["Square Neck", "Round Neck", "High Neck", "Bandeau", "One Shoulder"]

// Define the kind options for one-piece items (dresses).
let onePieceKindOptions = [
    "Mini Dress",
    "Midi Dress",
    "Maxi Dress",
    "High-Low Dress"
]

// Map each one-piece kind to its subkinds (in this case, all use the same dressSubkinds).
let onePieceSubkindMapping: [String: [String]] = [
    "Mini Dress": dressSubkinds,
    "Midi Dress": dressSubkinds,
    "Maxi Dress": dressSubkinds,
    "High-Low Dress": dressSubkinds
]

/// An instance of ClothingOptions for the One-Piece category.
let onePieceOptions = ClothingOptions(
    kindOptions: onePieceKindOptions,
    subkindMapping: onePieceSubkindMapping,
    finalOptions: dressStyles
)

// MARK: - Top Options Model
struct TopOptions {
    let kindOptions: [String]
    let subkindOptions: [String]
    let styleOptions: [String]
}
let topKindOptions = [
    "Bodysuit",
    "Cropped Top",
    "Full Length Top",
    "Mid Length Top"
]

let topSubkindOptions = [
    "Shirt",
    "Sweater",
    "Corset",
    "Else"
]

let topStyleOptions = [
    "T-shirt",
    "Tie-Neck",
    "Strappy",
    "Bandeau",
    "Buttondown",
    "SquareNeck",
    "Tank",
    "HighNeck",
    "RoundNeck",
    "One-Shoulder",
    "Off the Shoulder"
]

// Create an instance of TopOptions.
let topOptions = TopOptions(
    kindOptions: topKindOptions,
    subkindOptions: topSubkindOptions,
    styleOptions: topStyleOptions
)

// MARK: - Fabric Options Model
struct FabricOptions {
    let fabrics: [String]
}

// Define all possible fabric choices.
let allFabricOptions = FabricOptions(fabrics: [
    "None",
    "Wool Blend (Fine)",
    "Linen",
    "Denim",
    "Suede",
    "Leather",
    "Cotton",
    "Chiffon",
    "Polyester",
    "Jersey",
    "Silk",
    "Wool (Chunky Knit)",
    "Cashmere"
   
])

// MARK: - Colour Options Model

/// Represents a color option with a name and its hex code.
struct ColorOption {
    let name: String
    let hex: String
}

/// All available colors stored in one ordered array.
/// The comments indicate grouping by similar tones.
/// in view , hex codes will be displayed as a swatch .
let allColors: [ColorOption] = [
    // Black Tones
    ColorOption(name: "Onyx Black", hex: "#35383B"),
    ColorOption(name: "Jet Black", hex: "#343434"),
    
    // Blue Tones
    ColorOption(name: "Dodger Blue", hex: "#1E90FF"),
    ColorOption(name: "Royal Blue", hex: "#4169E1"),
    ColorOption(name: "Deep Sky Blue", hex: "#00BFFF"),
    
    // Brown Tones
    ColorOption(name: "Saddle Brown", hex: "#8B4513"),
    ColorOption(name: "Sienna Brown", hex: "#A0522D"),
    ColorOption(name: "Peru Brown", hex: "#CD853F"),
    
    // Denim Tones
    ColorOption(name: "Baby Blue Denim", hex: "#A9CCE3"),
    ColorOption(name: "Classic Blue Denim", hex: "#4682B4"),
    ColorOption(name: "Washed Black Denim", hex: "#2C2C2C"),
    ColorOption(name: "Deep Indigo Denim", hex: "#191970"),
    
    // Gray Tones
    ColorOption(name: "Dim Gray", hex: "#696969"),
    ColorOption(name: "Slate Gray", hex: "#708090"),
    
    // Green Tones
    ColorOption(name: "Sea Green", hex: "#2E8B57"),
    ColorOption(name: "Forest Green", hex: "#228B22"),
    ColorOption(name: "Lime Green", hex: "#32CD32"),
    
    // Orange Tones
    ColorOption(name: "Dark Orange", hex: "#FF8C00"),
    ColorOption(name: "Coral Orange", hex: "#FF7F50"),
    ColorOption(name: "Tomato Orange", hex: "#FF6347"),
    
    // Pink Tones
    ColorOption(name: "Light Pink", hex: "#FFB6C1"),
    ColorOption(name: "Hot Pink", hex: "#FF69B4"),
    
    // Purple Tones
    ColorOption(name: "Dark Orchid Purple", hex: "#9932CC"),
    ColorOption(name: "Plum Purple", hex: "#DDA0DD"),
    ColorOption(name: "Medium Orchid Purple", hex: "#BA55D3"),
    
    // Red Tones
    ColorOption(name: "Crimson Red", hex: "#DC143C"),
    ColorOption(name: "Indian Red", hex: "#CD5C5C"),
    ColorOption(name: "Firebrick Red", hex: "#B22222"),
    
    // White Tones
    ColorOption(name: "Snow White", hex: "#FFFAFA"),
    ColorOption(name: "Floral White", hex: "#FFFAF0"),
    
    // Yellow Tones
    ColorOption(name: "Khaki Yellow", hex: "#F0E68C"),
    ColorOption(name: "Gold Yellow", hex: "#FFD700")
]

// MARK: - Occasion Model
struct OccasionOption {
    let name: String
    
}
let allOccasions: [OccasionOption] = [
    OccasionOption(name: "Work (Corporate)"),
    OccasionOption(name: "Birthday Dinner (Glamorous)"),
    OccasionOption(name: "Aesthetic Brunch"),
    OccasionOption(name: "Casual Shopping"),
    OccasionOption(name: "Clubbing"),
    OccasionOption(name: "Work (Casual Stylish)"),
    OccasionOption(name: "Activity Date"),
    OccasionOption(name: "Birthday Party"),
    OccasionOption(name: "Travel")
]
