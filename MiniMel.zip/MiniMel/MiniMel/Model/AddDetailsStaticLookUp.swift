//
//  OptionsFile.swift
//  MiniMel
//
//  Created by Melissa Adesina on 08/05/2025.
//

import Foundation

// ————————————————————————————————
// Colour Options
// ————————————————————————————————

let allColorsUUID: [OptionItem] = [
    OptionItem(
        id:   UUID(uuidString: "004ce4df-6bf9-4f28-9b44-07fb2901c3b7")!,
        name: "Saddle Brown"
    ),
    OptionItem(
        id:   UUID(uuidString: "01818ce2-985f-47bc-a850-3d63e9eb28a9")!,
        name: "Dark Orange"
    ),
    OptionItem(
        id:   UUID(uuidString: "03645e45-0099-42be-9188-17c91da26b3a")!,
        name: "Sienna Brown"
    ),
    OptionItem(
        id:   UUID(uuidString: "03f704c8-5d9c-43c3-b54c-73b637e556c0")!,
        name: "Coral Orange"
    ),
    OptionItem(
        id:   UUID(uuidString: "11f02e24-79f2-4930-9fbf-cd435ae452ea")!,
        name: "Slate Gray"
    ),
    OptionItem(
        id:   UUID(uuidString: "14359032-bcd7-4ab9-8967-0fd2e232c4b7")!,
        name: "Light Pink"
    ),
    OptionItem(
        id:   UUID(uuidString: "232df930-415d-48cd-870d-674b2bc25abf")!,
        name: "Dim Gray"
    ),
    OptionItem(
        id:   UUID(uuidString: "26362fda-a610-444c-935f-65c9e4a82d36")!,
        name: "Onyx Black"
    ),
    OptionItem(
        id:   UUID(uuidString: "2662861c-bf0c-4d06-a85c-eabaad363a56")!,
        name: "Charcoal Black"
    ),
    OptionItem(
        id:   UUID(uuidString: "269a3c32-6f8f-4c53-8c1f-f527540e62a2")!,
        name: "Khaki Yellow"
    ),
    OptionItem(
        id:   UUID(uuidString: "2e683956-7058-4a42-9648-6dde70e0c622")!,
        name: "Dark Orchid Purple"
    ),
    OptionItem(
        id:   UUID(uuidString: "305b339e-3d7e-4476-86c4-137c2cc81edf")!,
        name: "Baby Blue Denim"
    ),
    OptionItem(
        id:   UUID(uuidString: "35e5e1e2-d120-4b54-b7e6-19ff6773f368")!,
        name: "Tomato Orange"
    ),
    OptionItem(
        id:   UUID(uuidString: "390089f6-d60b-45f5-a0b0-9a0c65eb4bcc")!,
        name: "Sea Green"
    ),
    OptionItem(
        id:   UUID(uuidString: "413af9a9-3565-4651-8b2d-0fe535d4e658")!,
        name: "Charcoal Grey Denim"
    ),
    OptionItem(
        id:   UUID(uuidString: "42b9263d-01ea-4f83-92b8-e6ae9e7468ed")!,
        name: "Light Slate Gray"
    ),
    OptionItem(
        id:   UUID(uuidString: "4d75ca35-72e9-4f55-8f16-300e2adcc787")!,
        name: "Jet Black"
    ),
    OptionItem(
        id:   UUID(uuidString: "4e3fb787-a407-4299-80ad-7d423097a9d2")!,
        name: "Deep Indigo Denim"
    ),
    OptionItem(
        id:   UUID(uuidString: "50aca6b2-cb40-47dd-be3c-ccc413d458cd")!,
        name: "Ivory White"
    ),
    OptionItem(
        id:   UUID(uuidString: "52b2a8e8-6fd8-4952-8e5d-58ce0a0ed6ed")!,
        name: "Deep Pink"
    ),
    OptionItem(
        id:   UUID(uuidString: "5745f08f-6ff1-42cf-bcee-03d9440c72b9")!,
        name: "Crimson Red"
    ),
    OptionItem(
        id:   UUID(uuidString: "5ee09b33-62e8-4d4e-8ba5-6a76dec6bb44")!,
        name: "Dodger Blue"
    ),
    OptionItem(
        id:   UUID(uuidString: "733dd9e2-9ac8-4e5d-9a3e-c71c78ae998f")!,
        name: "Gold Yellow"
    ),
    OptionItem(
        id:   UUID(uuidString: "8991e108-5dc4-4678-984b-9ebe5329fc30")!,
        name: "Classic Blue Denim"
    ),
    OptionItem(
        id:   UUID(uuidString: "89c3a195-178c-424d-bf9c-7db41c5e38e0")!,
        name: "Washed Black Denim"
    ),
    OptionItem(
        id:   UUID(uuidString: "8b1c4ccf-611f-4d75-9fb1-3013ae4dfa4b")!,
        name: "Royal Blue"
    ),
    OptionItem(
        id:   UUID(uuidString: "9516d867-c37b-44e0-89ee-1722c0d67ad7")!,
        name: "Light Goldenrod"
    ),
    OptionItem(
        id:   UUID(uuidString: "9a9687aa-c88b-4170-aee4-d4635167062f")!,
        name: "Snow White"
    ),
    OptionItem(
        id:   UUID(uuidString: "9b67fc6e-0e9a-45b8-bc54-4f404f01676d")!,
        name: "Hot Pink"
    ),
    OptionItem(
        id:   UUID(uuidString: "a298bc4a-614b-4f43-bc56-a1f4d2a96f00")!,
        name: "Indian Red"
    ),
    OptionItem(
        id:   UUID(uuidString: "a5e1fba6-c13a-47e8-a996-a34b8a13ffab")!,
        name: "Floral White"
    ),
    OptionItem(
        id:   UUID(uuidString: "ac655b57-f2ed-4153-902e-fcd606c14a9b")!,
        name: "Lime Green"
    ),
    OptionItem(
        id:   UUID(uuidString: "ac86b4a6-f19c-46b0-b078-28876c6a6063")!,
        name: "Forest Green"
    ),
    OptionItem(
        id:   UUID(uuidString: "c0c1372a-cee3-4aac-a70e-366f1d73a5b3")!,
        name: "Firebrick Red"
    ),
    OptionItem(
        id:   UUID(uuidString: "dd26cc13-18d3-4b14-9fb4-87462c45429b")!,
        name: "Deep Sky Blue"
    ),
    OptionItem(
        id:   UUID(uuidString: "e681011d-4ec3-42f5-a1a7-b65d6ea263b1")!,
        name: "Plum Purple"
    ),
    OptionItem(
        id:   UUID(uuidString: "ebceeb3c-55d8-4ec3-ac19-ce5f177e0313")!,
        name: "Peru Brown"
    ),
    OptionItem(
        id:   UUID(uuidString: "f395106f-508a-4879-af73-4dd9314f5175")!,
        name: "Medium Orchid Purple"
    )
]

// ────────────────────────────────────────────────────────
// Fabric Options
// ────────────────────────────────────────────────────────

let allFabricUUID: [OptionItem] = [
    OptionItem(
        id:   UUID(uuidString: "517ed327-4a0d-4312-8a7c-2572855ccfcd")!,
        name: "Wool Blend (Fine)"
    ),
    OptionItem(
        id:   UUID(uuidString: "5a13447d-f510-4daa-b4ca-547e2c60ce2e")!,
        name: "Linen"
    ),
    OptionItem(
        id:   UUID(uuidString: "6bfc9542-8e57-4c70-991b-24ab9ad2074b")!,
        name: "Denim"
    ),
    OptionItem(
        id:   UUID(uuidString: "7a6aa436-56d2-4b0b-a0de-ae6ec51e5320")!,
        name: "Suede"
    ),
    OptionItem(
        id:   UUID(uuidString: "7ddfc161-a584-4d6c-bd48-d8f3694ba69b")!,
        name: "Leather"
    ),
    OptionItem(
        id:   UUID(uuidString: "93868b8b-9221-40e9-aea0-35d2f3a4c927")!,
        name: "Cotton"
    ),
    OptionItem(
        id:   UUID(uuidString: "9dc469c3-1730-4303-a792-dcb3c8c9a70c")!,
        name: "None"
    ),
    OptionItem(
        id:   UUID(uuidString: "b6b6bfff-0de8-4398-b936-9c12b1c7a9b2")!,
        name: "Chiffon"
    ),
    OptionItem(
        id:   UUID(uuidString: "cabc6805-4a3a-43a1-8791-34ed6582cc82")!,
        name: "Polyester"
    ),
    OptionItem(
        id:   UUID(uuidString: "d2656e71-af82-4406-a3a1-16c58baf19a3")!,
        name: "Jersey"
    ),
    OptionItem(
        id:   UUID(uuidString: "d6ff4ac7-0615-498e-a4bb-5e85e8ed3b4f")!,
        name: "Silk"
    ),
    OptionItem(
        id:   UUID(uuidString: "df38df0b-adb9-4cd3-9aab-7f40e6e1729d")!,
        name: "Wool (Chunky Knit)"
    ),
    OptionItem(
        id:   UUID(uuidString: "f0206472-2464-4511-9603-231d7567a609")!,
        name: "Cashmere"
    )
]
 

// ────────────────────────────────────────────────────────
// Style Options
// ────────────────────────────────────────────────────────

let allStyleUUID: [OptionItem] = [
    // Shoe shapes
    OptionItem(
        id:   UUID(uuidString: "45431a13-7c36-44a6-9e91-cdbe75298884")!,
        name: "Round"
    ),
    OptionItem(
        id:   UUID(uuidString: "ba3c0c0e-d871-4543-a176-023f23c5f34b")!,
        name: "Pointed"
    ),
    OptionItem(
        id:   UUID(uuidString: "38570a16-a592-41d8-bc6d-4781317b417d")!,
        name: "Square"
    ),

    // Bottom rise
    OptionItem(
        id:   UUID(uuidString: "051fb853-e351-4450-8ecc-301c44234c94")!,
        name: "High-Rise"
    ),
    OptionItem(
        id:   UUID(uuidString: "6fb70b95-ee39-48fc-a602-334c51579f97")!,
        name: "Mid-Rise"
    ),
    OptionItem(
        id:   UUID(uuidString: "7bd7d8a8-e31e-4394-9e0e-c813547b4219")!,
        name: "Low-Rise"
    ),

    // Top styles
    OptionItem(
        id:   UUID(uuidString: "1e72a5a0-d0e7-415f-b95a-77316b2315cd")!,
        name: "T-shirt"
    ),
    OptionItem(
        id:   UUID(uuidString: "2636e533-d216-47aa-b9c8-e4bad21317d5")!,
        name: "Tie-Neck"
    ),
    OptionItem(
        id:   UUID(uuidString: "3725478c-1eff-4653-ab82-670f586f5419")!,
        name: "Strappy"
    ),
    OptionItem(
        id:   UUID(uuidString: "46e0a795-8f03-4436-949d-58a479868d84")!,
        name: "Bandeau"
    ),
    OptionItem(
        id:   UUID(uuidString: "92b08d40-ca2e-4064-9596-4d8093aadd32")!,
        name: "Buttondown"
    ),
    OptionItem(
        id:   UUID(uuidString: "bfdb2b72-2ed0-4b6d-88c6-45c62e3a81a9")!,
        name: "Tank"
    ),

    // Necklines (also used for dresses) -
    OptionItem(
        id:   UUID(uuidString: "930f6fe0-78e0-4989-8f0d-6216b4ea3140")!,
        name: "Square Neck"
    ),
    OptionItem(
        id:   UUID(uuidString: "f6g7h8i9-j0k1-2345-6789-0abcdef12345")!,
        name: "Round Neck"
    ),
    OptionItem(
        id:   UUID(uuidString: "g7h8i9j0-k1l2-3456-789a-bcdef1234567")!,
        name: "High Neck"
    ),
    OptionItem(
        id:   UUID(uuidString: "h8i9j0k1-l2m3-4567-89ab-cdef12345678")!,
        name: "One Shoulder"
    ),
    
    // Dress-specific variants
    OptionItem(
        id:   UUID(uuidString: "41542941-0ff8-4d61-a231-a7121590e4a0")!,
        name: "One-Shoulder"
    ),
    OptionItem(
        id:   UUID(uuidString: "43982462-b771-44e1-987f-bcdaa31c73cb")!,
        name: "Off the Shoulder"
    )
]

let subkindUUIDs: [String: UUID] = [
  // Skirts
  "Bubble":   UUID(uuidString: "e983b42f-6704-491f-b88a-12a4f4b2ad5b")!,
  "Pleated":  UUID(uuidString: "c71a8cdc-5b3f-496a-b514-9f1a0e865c71")!,
  "Flared":   UUID(uuidString: "937c0340-aea6-4b28-be37-b13f60e409c1")!,
  "Frill":    UUID(uuidString: "fbd460dd-9fdd-47a8-85b6-aba255e1ec92")!,

  // Dress subkinds - using actual UUIDs from your database
  "A-line":       UUID(uuidString: "e7200fb6-e68e-4d88-afc6-7b5c45544ffc")!,
  "Tulle Skirt":  UUID(uuidString: "b94d3576-f8d6-4c5d-a5ab-b89b5f913919")!,
  "Bodycon":      UUID(uuidString: "2d2e49bf-dd3b-4640-bbf4-2bfbd29404f3")!,

  // Shorts
  "Jorts":    UUID(uuidString: "24a1eca6-e600-4b51-94af-e0b38aa36647")!,
  "Capris":   UUID(uuidString: "296ccffe-5d4c-4a5b-ae83-f34b229a3fda")!,
  "tailored": UUID(uuidString: "a59d4b23-74b2-4f1e-8c6c-0bcc934913ef")!,

  // Jeans/Trousers
  "Skinny":       UUID(uuidString: "0be4cf2c-2706-454c-9849-ffc34a2d466c")!,
  "Bootcut":      UUID(uuidString: "165a389a-981e-479f-aa27-5e4245679408")!,
  "Straight Leg": UUID(uuidString: "190bc17d-249b-4c18-90dc-11fdfaa49c9c")!,
  "Wide Leg":     UUID(uuidString: "4b788deb-37c9-402b-8e13-b3e44776eba3")!,

  // Shoe sub-kinds
  "Boots":       UUID(uuidString: "a7ca9701-d45e-4234-86f1-08865af5858f")!,
  "Strap Up":    UUID(uuidString: "9b531000-5e36-43e2-98c5-1587bd629bf0")!,
  "Mules":       UUID(uuidString: "323be399-fbce-40f3-bb8c-905e62fee5a9")!,
  "Trainers":    UUID(uuidString: "cf874b3e-737b-4296-bc7e-e0ab557cf50d")!,
  "Loafers":     UUID(uuidString: "57849f0a-5868-46fb-bd90-79f009456850")!,
  "Ankle-strap": UUID(uuidString: "fcbed8ad-f884-48d2-9261-57863d2f96ff")!,

  // Top sub-kinds
  "Shirt":     UUID(uuidString: "91e6a12f-10ec-482b-92f4-d1527d81fa85")!,
  "Sweater":   UUID(uuidString: "9103137c-7bd1-4286-8677-3167944c6873")!,
  "Corset":    UUID(uuidString: "8172131b-edc4-4840-b9a8-106abd8c6367")!,
  "Else":      UUID(uuidString: "c525e5fd-0c7c-4fb4-b21c-bf4f30c19578")!,
  "Basic":     UUID(uuidString: "011c66c1-088e-4dbd-acda-adf67d8af1d6")!
]

let heelTypeUUIDs: [String: UUID] = [
  "Block Heel":   UUID(uuidString: "0e2639bb-b946-4815-8c9a-eb22df29e103")!,
  "Kitten Heel":  UUID(uuidString: "3c3062be-7299-42fa-ab80-e457224d3ad4")!,
  "Flat":         UUID(uuidString: "3df434bc-2377-4181-9e4c-9d9a49086abb")!,
  "Stiletto":     UUID(uuidString: "3f418937-d219-4f1b-b0cf-c1651f2f8202")!,
  "Platform":     UUID(uuidString: "53bd1cb3-e3b9-4397-8f1a-e1bb76c6cca3")!,
  "Wedge":        UUID(uuidString: "70b67e25-40a6-410d-b0bd-d956e5947ee7")!
]

let kindUUIDs: [String: UUID] = [
  "Cropped Top":       UUID(uuidString: "13094c66-d950-478f-8850-7b91c586f230")!,
  "Mini Dress":        UUID(uuidString: "137ef545-cf06-4074-afe5-476256be90e9")!,
  "Maxi Skirt":        UUID(uuidString: "1f32a24d-2dc1-4206-aacc-40b30d369d9e")!,
  "Open-toe Shoe":     UUID(uuidString: "246e5a9c-6fd5-4f3f-8a5c-a7a5599f7686")!,
  "Maxi Dress":        UUID(uuidString: "25f15dc6-d63d-4feb-8585-765f8ef1a7d6")!,
  "Mid Length Top":    UUID(uuidString: "2b030a8a-80f1-4e7c-9b28-a3629a7f15b5")!,
  "Jeans:Trousers":    UUID(uuidString: "2f1993de-f942-4619-ae3e-af26a87a4ea1")!,
  "Knee Shorts":       UUID(uuidString: "4df9f72a-01e3-46ba-a12e-b52e93fed995")!,
  "Midi Dress":        UUID(uuidString: "6f1fc034-4a3f-4e0d-98bc-994637b920fa")!,
  "Full Length Top":   UUID(uuidString: "7f563ad0-4784-415c-b5f5-310dd8f5e38f")!,
  "Mini Shorts":       UUID(uuidString: "914644c2-5c76-4f5e-995c-b541e115e1c9")!,
  "Closed-toe Shoe":   UUID(uuidString: "9f650ce8-88b8-4d12-81f4-9672d6368c7d")!,
  "Mini Skirt":        UUID(uuidString: "e4014887-2a3b-439d-badb-e2f59cc23b0c")!,
  "Bodysuit":          UUID(uuidString: "ea9ae4f5-3f29-49dc-8754-38aae5fe0d4b")!,
  "High-Low Dress":    UUID(uuidString: "ef8d3689-6f6f-4d36-a1fa-e078a88be6f5")!,
  "Midi Skirt":        UUID(uuidString: "f6f1d62a-313e-4435-8c50-03efa4ef8dd7")!
]
 
let occasionUUIDs: [String: UUID] = [
  "Work (Corporate)":         UUID(uuidString: "011b3f64-9e29-4381-9aad-56fd77daf9fd")!,
  "Birthday Dinner (Glamorous)": UUID(uuidString: "12422e2f-d714-4d40-b08d-d676f65cc602")!,
  "Aesthetic Brunch":         UUID(uuidString: "18cff91f-0461-4075-b8af-b1882614209e")!,
  "Casual Shopping":          UUID(uuidString: "31b90636-1c00-42bc-87ac-c7f1557b910c")!,
  "Clubbing":                 UUID(uuidString: "3dbf71d8-5c4e-40bd-aea8-57c436fcac14")!,
  "Work (Casual Stylish)":    UUID(uuidString: "63351750-1c36-4d82-a172-ba4fbfa113f8")!,
  "Activity Date":            UUID(uuidString: "9d3a8eb6-7c61-4beb-ac63-16ab35952243")!,
  "Birthday Party":           UUID(uuidString: "c54ca86e-0741-4cdc-87d4-cc731e73c15c")!,
  "Travel":                   UUID(uuidString: "e5c5ff10-8aa3-4c9e-b092-d03735f2be4a")!
]
