//
//  ClothingItem.swift
//  MiniMel
//
//  Created by Melissa Adesina on 14/05/2025.
//
import Foundation

extension ClothingItem {
  /// A lightweight initializer for previews—fills in a dummy payload.
  init(stubId: String, stubImageURL: URL) {
    self.id = stubId
    self.imageURL = stubImageURL
    // provide whatever reasonable “empty” payload your type needs:
  
  }

  /// Returns three stub items for SwiftUI previews
  static func placeholderItems() -> [ClothingItem] {
    return [
      .init(
        stubId:       "1",
        stubImageURL: URL(string: "https://via.placeholder.com/300")!
      ),
      .init(
        stubId:       "2",
        stubImageURL: URL(string: "https://via.placeholder.com/300/ff6666")!
      ),
      .init(
        stubId:       "3",
        stubImageURL: URL(string: "https://via.placeholder.com/300/66ff66")!
      ),
    ]
  }
}
