//
//  WardrobeModel.swift
//  MiniMel
//
//  Created by Melissa Adesina on 11/05/2025.
//

import Foundation

struct ClothingItem: Identifiable {
  let id: String
  let imageURL: URL

  init?(payload: WardrobeItemPayload) {
    guard let url = URL(string: payload.image) else { return nil }
    self.id       = payload.wardrobe_item_id
    self.imageURL = url
  }
}



struct WardrobeCategory: Decodable, Identifiable {
  let category_id: Int
  let name: String
  var id: Int { category_id }
}

public protocol WardrobeItemRepresentable {
  var imageURL: String { get }
}

public struct WardrobeItemWithCategory: Decodable, Identifiable, WardrobeItemRepresentable {
    let wardrobe_item_id: UUID
    let image:            String

    struct Kind: Decodable {
        struct Category: Decodable {
            let name: String
        }
        let category: Category
    }
    let kind: Kind

    public var id: UUID { wardrobe_item_id }
    public var imageURL: String { image }
}

public struct WardrobeItemWithFullDetails: Decodable, Identifiable, WardrobeItemRepresentable {
    let wardrobe_item_id: UUID
    let image: String
    let kind_id: String
    let subkind_id: String
    let style_id: String

    struct Kind: Decodable {
        let kind_id: String
        let name: String
        struct Category: Decodable {
            let name: String
        }
        let category: Category
    }
    let kind: Kind

    struct Fabric: Decodable {
        let fabric_id: String
        let name: String
    }
    let primary_fabric: Fabric
    let secondary_fabric: Fabric

    public var id: UUID { wardrobe_item_id }
    public var imageURL: String { image }
    
    var hasLinenFabric: Bool {
        return primary_fabric.name.lowercased().contains("linen") ||
               secondary_fabric.name.lowercased().contains("linen")
    }
    
    var isOpenToeShoe: Bool {
        return kind.category.name.lowercased().contains("shoe") &&
               kind.name.lowercased().contains("open-toe")
    }
}

public struct SavedOutfit: Identifiable, Codable {
  public let id: UUID
  public let userId: UUID
  public let occasionId: UUID
  public let topId: String?
  public let bottomId: String?
  public let shoeId: String
  public let onePieceId: String?
  public let savedAt: Date

  enum CodingKeys: String, CodingKey {
    case id          = "outfit_id"
    case userId      = "user_id"
    case occasionId  = "occasion_id"
    case topId       = "top_id"
    case bottomId    = "bottom_id"
    case shoeId      = "shoe_id"
    case onePieceId  = "one_piece_id"
    case savedAt     = "saved_at"
  }
}

struct OccasionRecord: Decodable, Identifiable {
  let occasion_id: UUID
  let name:          String

  var id: UUID { occasion_id }
}
