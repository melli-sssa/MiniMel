// Models.swift
import Foundation
// MARK: – In-memory "Outfit" combiner
public struct Outfit: Identifiable {
  public let id       = UUID()
  public let top:      WardrobeItemWithCategory?
  public let bottom:   WardrobeItemWithCategory?
  public let onePiece: WardrobeItemWithCategory?
  public let shoe:     WardrobeItemWithCategory
}

public struct DetailedOutfit: Identifiable {
  public let id       = UUID()
  public let top:      WardrobeItemWithFullDetails?
  public let bottom:   WardrobeItemWithFullDetails?
  public let onePiece: WardrobeItemWithFullDetails?
  public let shoe:     WardrobeItemWithFullDetails
  
  // Convert to regular Outfit for UI display
  public var asOutfit: Outfit {
    return Outfit(
      top: top?.asWardrobeItemWithCategory,
      bottom: bottom?.asWardrobeItemWithCategory,
      onePiece: onePiece?.asWardrobeItemWithCategory,
      shoe: shoe.asWardrobeItemWithCategory
    )
  }
  
  // Helper method to check travel styling rules
  public var meetsTravelCriteria: Bool {
    let hasLinenClothing = top?.hasLinenFabric == true || 
                          bottom?.hasLinenFabric == true || 
                          onePiece?.hasLinenFabric == true
    let hasOpenToeShoe = shoe.isOpenToeShoe
    
    return hasLinenClothing && hasOpenToeShoe
  }
}

extension WardrobeItemWithFullDetails {
  var asWardrobeItemWithCategory: WardrobeItemWithCategory {
    return WardrobeItemWithCategory(
      wardrobe_item_id: self.wardrobe_item_id,
      image: self.image,
      kind: WardrobeItemWithCategory.Kind(
        category: WardrobeItemWithCategory.Kind.Category(name: self.kind.category.name)
      )
    )
  }
}
