//
//  dropdownMenu.swift
//  MiniMel
//
//  Created by Melissa Adesina on 03/05/2025.
//

// CustomDropdown.swift
import SwiftUI

struct CustomDropdown: View {
    // 1) The user’s current selection
    @Binding var selection: String?
    // 2) Controlled expansion state (parent drives which is open)
    @Binding var isExpanded: Bool

    let placeholder: String
    let options: [String]

    // internal scroll thumb offset
    @State private var scrollOffset: CGFloat = 0

    var body: some View {
        VStack(spacing: 0) {
            // ─── Header ─────────────────────────────────
            HStack {
                Text(selection ?? placeholder)
                    .foregroundColor(selection == nil ? .gray : .black)
                    .font(.system(size: 16, weight: .bold, design: .monospaced))
                Spacer()
                Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                    .font(.system(size: 16))
                    .foregroundColor(.pink)
            }
            .padding(.vertical, 8)
            .padding(.horizontal)
            .background(Color(red: 1.0, green: 0.88, blue: 0.94).opacity(0.7))
            .overlay(RoundedRectangle(cornerRadius: 4).stroke(Color.black, lineWidth: 1))
            .onTapGesture { isExpanded.toggle() }

            // ─── Options ────────────────────────────────
            if isExpanded {
                ScrollViewReader { proxy in
                    HStack(spacing: 0) {
                        // Options list
                        ScrollView(.vertical, showsIndicators: false) {
                            VStack(spacing: 0) {
                                ForEach(Array(options.enumerated()), id: \.0) { index, option in
                                    // <<< Swatch + Label Row >>>
                                    HStack(spacing: 8) {
                                        // draw color swatch if this option matches a ColorOption
                                        if let hex = allColors.first(where: { $0.name == option })?.hex,
                                           let swatch = Color(hex: hex)
                                        {
                                            Rectangle()
                                                .fill(swatch)
                                                .frame(width: 16, height: 16)
                                                .cornerRadius(2)
                                        }

                                        Text(option)
                                            .font(.system(size: 16, weight: .bold, design: .monospaced))
                                            .foregroundColor(.black)

                                        Spacer()
                                    }
                                    .padding(.vertical, 12)
                                    .padding(.horizontal)
                                    .contentShape(Rectangle())
                                    .onTapGesture {
                                        selection = option
                                        isExpanded = false
                                    }
                                    .id(index)

                                    // Divider between items
                                    if index < options.count - 1 {
                                        VStack(spacing: 0) {
                                            Rectangle()
                                                .fill(Color.pink)
                                                .frame(height: 1)
                                            Rectangle()
                                                .fill(Color(red: 1.0, green: 0.88, blue: 0.94))
                                                .frame(height: 1)
                                        }
                                    }
                                }
                            }
                        }
                        .background(Color.white.opacity(0.9)) 
                        .scrollBounceBehavior(.basedOnSize)
                        .overlay(RoundedRectangle(cornerRadius: 0).stroke(Color.black, lineWidth: 1))

                        // … your existing scrollbar code here …
                    }
                    .frame(maxHeight: 200)
                }
            }
        }
    }
}

// Selective corner radius helper
fileprivate extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

fileprivate struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    func path(in rect: CGRect) -> Path {
        Path(UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        ).cgPath)
    }
}
