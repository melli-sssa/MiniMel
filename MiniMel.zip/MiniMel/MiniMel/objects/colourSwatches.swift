//
//  colourSwatches.swift
//  MiniMel
//
//  Created by Melissa Adesina on 06/05/2025.
//

import SwiftUI

extension Color {
    /// Initialise 
    init?(hex: String) {
        // Strip out non-hex characters
        let hex = hex.trimmingCharacters(in: .alphanumerics.inverted)
        var int: UInt64 = 0
        guard Scanner(string: hex).scanHexInt64(&int) else { return nil }

        let r, g, b, a: UInt64
        switch hex.count {
        case 6: // RRGGBB
            (r, g, b, a) = ((int >> 16) & 0xFF,
                            (int >>  8) & 0xFF,
                             int        & 0xFF,
                             0xFF)
        case 8: // AARRGGBB
            (a, r, g, b) = ((int >> 24) & 0xFF,
                            (int >> 16) & 0xFF,
                            (int >>  8) & 0xFF,
                             int        & 0xFF)
        default:
            return nil
        }

        self.init(
            .sRGB,
            red:   Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}
