//
//  GeneratedOutfit.swift
//  MiniMel
//
//  Created by Melissa Adesina on 19/05/2025.
//

import SwiftUI

/// A reusable “card” for any wardrobe item in an outfit.
struct GeneratedOutfitDisplay<Item: WardrobeItemRepresentable>: View {
    let item: Item
    let label: String?
    var showShadow: Bool = true
    var imageMaxHeight: CGFloat = 220

    var body: some View {
        ZStack(alignment: .topLeading) {
            // The item's image
            AsyncImage(url: URL(string: item.imageURL)) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .frame(height: imageMaxHeight)
                        .background(Color.clear)
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: imageMaxHeight)
                        .background(Color.clear)
                case .failure(_):
                    Image(systemName: "photo")
                        .font(.system(size: 40))
                        .foregroundColor(.gray.opacity(0.6))
                        .frame(height: imageMaxHeight)
                        .background(Color.clear)
                @unknown default:
                    EmptyView()
                        .background(Color.clear)
                }
            }
            .frame(maxHeight: imageMaxHeight)
            .background(Color.clear)

            if let label = label {
                VStack {
                    HStack {
                        Text(shortenLabel(label))
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .foregroundColor(.black)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color(red: 1.0, green: 0.88, blue: 0.94))
                            )
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        Spacer()
                    }
                    Spacer()
                }
                .padding(8)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(maxHeight: imageMaxHeight)
    }
    
    // Helper function to shorten labels
    private func shortenLabel(_ label: String) -> String {
        switch label {
        case "One Piece":
            return "Dress"
        case "Shoes":
            return "Shoes"
        default:
            return label
        }
    }
}

struct ConditionalShadowModifier: ViewModifier {
    let showShadow: Bool
    
    func body(content: Content) -> some View {
        if showShadow {
            content.shadow(color: Color.black.opacity(0.08), radius: 8, x: 0, y: 4)
        } else {
            content
        }
    }
}
