//
//  checkBox.swift
//  MiniMel
//
//  Created by Melissa Adesina on 06/05/2025.
//
import SwiftUI

struct PinkCheckbox: View {
    @Binding var isChecked: Bool
    var onToggle: ((Bool) -> Void)? = nil

    var body: some View {
        Button {
            isChecked.toggle()
            onToggle?(isChecked)
        } label: {
            ZStack {
                RoundedRectangle(cornerRadius: 4)
                    .stroke(Color.pink, lineWidth: 2)
                    .frame(width: 24, height: 24)

                if isChecked {
                    RoundedRectangle(cornerRadius: 4)
                        .fill(Color.pink.opacity(0.3))
                        .frame(width: 24, height: 24)

                    Image("pngaaa.com-2658974")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 5, height: 5)
                }
            }
        }
        .buttonStyle(.plain)
    }
}

// SubmitButton.swift
struct SubmitButton: View {
    var title: String = "Submit"
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(.body, design: .monospaced)) 
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, minHeight: 44) 
        }
        .buttonStyle(.plain)
        .background(Color.pink.opacity(0.3))
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(Color.pink, lineWidth: 3)
        )
        .cornerRadius(22)
    }
}
