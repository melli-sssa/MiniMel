//
//  Navigation.swift
//  MiniMel
//
//  Created by Melissa Adesina on 15/05/2025.
//

import SwiftUI

/// Which tab is active?
enum ActiveTab: CaseIterable {
    case wardrobe, favorites, generate
}

struct RootContainerView: View {
    let userID: String
    @EnvironmentObject var authVM: AuthViewModel
    @Binding var activeTab: ActiveTab
    @State private var showProfileSheet = false
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                TopNavView(activeTab: activeTab, showProfileSheet: $showProfileSheet)
                
                TabView(selection: $activeTab) {
                    WardrobeView(userID: userID)
                        .tag(ActiveTab.wardrobe)
                    
                    FavoritesView(userID: userID)
                        .tag(ActiveTab.favorites)
                    
                    GenerateOutfitView(userID: userID)
                        .tag(ActiveTab.generate)
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                
                BottomNavView(activeTab: $activeTab)
            }
            .background(
                // Grid background for content area only
                Image("Grid")
                    .resizable(resizingMode: .tile)
                    .opacity(0.12)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            )
        }
        .background(
            // White background for safe areas
            Color.white.ignoresSafeArea(.all)
        )
        .overlay(
            Group {
                if showProfileSheet {
                    ZStack {
                        Color.black.opacity(0.6)
                            .ignoresSafeArea()
                        
                        Rectangle()
                            .fill(.ultraThinMaterial)
                            .blur(radius: 18)
                            .ignoresSafeArea()
                            .onTapGesture {
                                showProfileSheet = false
                            }
                        
                        // Centered profile card
                        ProfileCardView(userID: userID, showProfileSheet: $showProfileSheet)
                            .environmentObject(authVM)
                    }
                }
            }
            .animation(.easeInOut(duration: 0.3), value: showProfileSheet)
        )
    }
    
    struct TopNavView: View {
        let activeTab: ActiveTab
        @Binding var showProfileSheet: Bool
        
        var body: some View {
            HStack {
                Button(action: {
                    showProfileSheet = true
                }) {
                    Image(systemName: "person.circle")
                        .font(.system(size: 28, weight: .light))
                        .foregroundColor(.black.opacity(0.7))
                }
                
                Spacer()
                
                Text(titleForTab(activeTab))
                    .font(.system(size: 28, weight: .bold, design: .monospaced))
                    .foregroundColor(.primary)
                
                Spacer()
                
                Image(systemName: "person.circle")
                    .font(.system(size: 28, weight: .light))
                    .foregroundColor(.clear)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)
            .background(
                Color.white.opacity(0.7)
                    .shadow(color: Color.black.opacity(0.05), radius: 2, x: 0, y: 1)
            )
            .overlay(
                Rectangle()
                    .frame(height: 2)
                    .foregroundColor(.black),
                alignment: .bottom
            )
        }
        
        private func titleForTab(_ tab: ActiveTab) -> String {
            switch tab {
            case .wardrobe:
                return "MiniMel"
            case .favorites:
                return "MiniMel"
            case .generate:
                return "MiniMel"
            }
        }
    }
    
    struct BottomNavView: View {
        @Binding var activeTab: ActiveTab
        
        var body: some View {
            VStack(spacing: 0) {
                Rectangle()
                    .frame(height: 2)
                    .foregroundColor(.black)
                
                HStack(spacing: 0) {
                    ForEach(ActiveTab.allCases, id: \.self) { tab in
                        Button(action: {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                activeTab = tab
                            }
                        }) {
                            VStack(spacing: 6) {
                                Image(systemName: iconForTab(tab))
                                    .font(.system(size: 22, weight: .medium))
                                    .foregroundColor(activeTab == tab ? .pink : .black.opacity(0.6))
                                    .scaleEffect(activeTab == tab ? 1.1 : 1.0)
                                
                                Text(labelForTab(tab))
                                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                                    .foregroundColor(activeTab == tab ? .pink : .black.opacity(0.6))
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                        }
                        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: activeTab)
                    }
                }
                .background(Color.white.opacity(0.95))
            }
        }
        
        private func iconForTab(_ tab: ActiveTab) -> String {
            switch tab {
            case .wardrobe: return "cabinet.fill" 
            case .favorites: return "heart.fill"
            case .generate: return "sparkles"
            }
        }
        
        private func labelForTab(_ tab: ActiveTab) -> String {
            switch tab {
            case .wardrobe: return "Wardrobe"
            case .favorites: return "Favorites"
            case .generate: return "Generate"
            }
        }
    }
}

struct ProfileCardView: View {
    let userID: String
    @Binding var showProfileSheet: Bool
    @EnvironmentObject var authVM: AuthViewModel
    @StateObject private var wardrobeVM: WardrobeViewModel
    @State private var userName: String = "User"
    
    init(userID: String, showProfileSheet: Binding<Bool>) {
        self.userID = userID
        self._showProfileSheet = showProfileSheet
        self._wardrobeVM = StateObject(wrappedValue: WardrobeViewModel(userID: userID))
        self._favoritesVM = StateObject(wrappedValue: FavoritesViewModel(userID: userID))
    }
    
    @StateObject private var favoritesVM: FavoritesViewModel
    
    var body: some View {
        VStack(spacing: 20) {
            // Header with close button
            HStack {
                Spacer()
                Button(action: { showProfileSheet = false }) {
                    Image(systemName: "xmark")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                        .padding(8)
                        .background(Color.gray.opacity(0.1))
                        .clipShape(Circle())
                }
            }
            
            VStack(spacing: 16) {
                Text("Fashionista \(userName)! ")
                    .font(.system(size: 24, weight: .bold, design: .monospaced))
                    .foregroundColor(Color(red: 1.0, green: 0.75, blue: 0.85))
                
                // Stats
                HStack(spacing: 40) {
                    VStack(spacing: 4) {
                        Text("\(wardrobeVM.items.count)")
                            .font(.system(size: 28, weight: .bold, design: .monospaced))
                            .foregroundColor(.primary)
                        Text("Wardrobe Items")
                            .font(.system(size: 12, weight: .medium, design: .monospaced))
                            .foregroundColor(.secondary)
                    }
                    
                    VStack(spacing: 4) {
                        Text("\(favoritesVM.outfits.count)")
                            .font(.system(size: 28, weight: .bold, design: .monospaced))
                            .foregroundColor(.primary)
                        Text("Saved Outfits")
                            .font(.system(size: 12, weight: .medium, design: .monospaced))
                            .foregroundColor(.secondary)
                    }
                }
                .padding(.vertical, 8)
            }
            
            Button(action: {
                authVM.signOut()
                showProfileSheet = false
            }) {
                HStack {
                    Image(systemName: "arrow.right.square")
                    Text("Logout")
                }
                .font(.system(size: 16, weight: .semibold, design: .monospaced))
                .foregroundColor(.white)
                .padding(.horizontal, 32)
                .padding(.vertical, 12)
                .background(Color(red: 1.0, green: 0.75, blue: 0.85))
                .cornerRadius(25)
                .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
            }
        }
        .padding(24)
        .frame(width: 350, height: 280) 
        .background(Color.white)
        .cornerRadius(20)
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.black, lineWidth: 2) 
        )
        .shadow(color: Color.black.opacity(0.3), radius: 15, x: 0, y: 5)
        .onAppear {
            // Load data when sheet appears
            if let uuid = authVM.userID {
                Task {
                    await wardrobeVM.loadItems(for: uuid.uuidString)
                    await favoritesVM.fetchSavedOutfits()
                    await loadUserName()
                }
            }
        }
    }
    
    private func loadUserName() async {
        do {
            let client = SupabaseClientManager.shared.getClient()
            let currentUser = try await client.auth.user()
            
            // Debug: Print the raw metadata
            print("DEBUG: Raw user metadata: \(currentUser.userMetadata)")
            
            if let nameAnyJSON = currentUser.userMetadata["name"] {
                print("DEBUG: Name AnyJSON: \(nameAnyJSON)")
                
                await MainActor.run {
                    // Convert AnyJSON to string - try different approaches
                    let nameString = "\(nameAnyJSON)".replacingOccurrences(of: "\"", with: "")
                    self.userName = nameString.isEmpty ? "User" : nameString
                    print("DEBUG: Final userName: \(self.userName)")
                }
            }
        } catch {
            print("Error loading user name: \(error)")
        }
    }
}
