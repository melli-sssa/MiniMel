//
//  forwardArrow.swift
//  MiniMel
//
//  Created by Melissa Adesina on 05/05/2025.
//
import SwiftUI

struct PinkForwardButton: View {
    var action: () -> Void // Closure for button tap action

    var body: some View {
        Button(action: action) {
            ZStack {
                // Background Circle
                Circle()
                    .fill(Color.pink.opacity(0.3))
                    .frame(width: 60, height: 60)
                    .overlay(
                        Circle().stroke(Color.pink, lineWidth: 3)
                    )

                // Right Arrow
                Path { path in
                    path.move(to: CGPoint(x: 25, y: 25))
                    path.addLine(to: CGPoint(x: 35, y: 30))
                    path.addLine(to: CGPoint(x: 25, y: 35))
                }
                .stroke(style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
                .foregroundColor(.pink)

                // Decorative arc stroke (mirrored)
                Path { path in
                    path.addArc(center: CGPoint(x: 30, y: 30),
                                radius: 20,
                                startAngle: .degrees(210),
                                endAngle: .degrees(260),
                                clockwise: false)
                }
                .stroke(Color.pink.opacity(0.5), lineWidth: 2)
            }
            .scaleEffect(0.4) // Uniformly scale down everything
        }
        .frame(width: 24, height: 24) // Visible button size
    }
}

struct PinkForwardButton_Previews: PreviewProvider {
    static var previews: some View {
        PinkForwardButton {
            print("Forward arrow tapped!")
        }
    }
}
