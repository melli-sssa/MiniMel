//
//  AddDetailsViewModel.swift
//  MiniMel
//
//  Created by Melissa Adesina on 01/04/2025.
//

// AddDetailsViewModel.swift
// AddDetailsViewModel.swift
import SwiftUI
import Combine
import UIKit
import CoreML

final class AddDetailsViewModel: ObservableObject {
    // MARK: – Published UI State
    @Published var currentPage = 1
    @Published var dropdownOptions: [[String]] = []
    
    // Two separate, fixed‑length selection arrays:
    //  • page1 has 5 dropdowns
    //  • page2 has 3 dropdowns
    @Published var page1Selections = Array<String?>(repeating: nil, count: 4)
    @Published var page2Selections = Array<String?>(repeating: nil, count: 3)
    
    @Published var expandedIndex: Int?           = nil
    @Published var occasions: [OccasionOption]   = []
    @Published var selectedOccasions: Set<String> = []
    @Published var isSubmitting: Bool = false
    
    //ml model auto tagging
    @Published var isClassifying = false
    @Published var classificationFailed = false

    // uder ID
    let userID: String
    private let repo: WardrobeRepository
    // ─────────────────────────────────────────────────────────────────
    // Backups & one‐time flags
    // ─────────────────────────────────────────────────────────────────
    private var page1OptionsBackup: [[String]] = []
    private var didSetupPage3 = false
  
  
    @Published var selectedImage: UIImage? {
      didSet {
        guard let img = selectedImage else { return }
        // Use the four-stage classification function
        let result = classifyImage(img)
        page1Selections[0] = result.category
        selectionChanged(at: 0, to: result.category)
        
        // If ML model provided a kind suggestion, use it
        if let kind = result.kind {
            page1Selections[1] = kind
            selectionChanged(at: 1, to: kind)
        }
        
        // If ML model provided a subkind suggestion, use it
        if let subkind = result.subkind {
            page1Selections[2] = subkind
            selectionChanged(at: 2, to: subkind)
        }
        
        if let style = result.style {
            page1Selections[3] = style
            selectionChanged(at: 3, to: style)
        }
      }
    }

    // ─────────────────────────────────────────────────────────────────
    // Init
    // ─────────────────────────────────────────────────────────────────
   
    init(initialImage: UIImage? = nil,
         userID: String,
         repo: WardrobeRepository = SupabaseWardrobeRepository()) {
        self.userID = userID
        self.repo   = repo
        setupPage1()
        self.selectedImage = initialImage

        // First-run classify with four-stage function
        if let img = initialImage {
          let result = classifyImage(img)
          page1Selections[0] = result.category
          selectionChanged(at: 0, to: result.category)
          
          // If ML model provided a kind suggestion, use it
          if let kind = result.kind {
              page1Selections[1] = kind
              selectionChanged(at: 1, to: kind)
          }
          
          // If ML model provided a subkind suggestion, use it
          if let subkind = result.subkind {
              page1Selections[2] = subkind
              selectionChanged(at: 2, to: subkind)
          }
          
          if let style = result.style {
              page1Selections[3] = style
              selectionChanged(at: 3, to: style)
          }
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // check all values are not nil before submitting form
    // ─────────────────────────────────────────────────────────────────
    var canSubmit: Bool {
        // page1Selections = [Category, Kind, Subkind, Style]
        // page2Selections = [PrimaryFabric, SecondaryFabric, Color]
        // selectedOccasions = Set<String>
        // – ensure *all* page1 + all page2 + at least one occasion are non-nil
        let part1 = page1Selections.allSatisfy { $0 != nil }
        let part2 = page2Selections.allSatisfy { $0 != nil }
        let part3 = !selectedOccasions.isEmpty
        return part1 && part2 && part3
    }

    // ─────────────────────────────────────────────────────────────────
    // Navigation
    // ─────────────────────────────────────────────────────────────────
    func goForward() {
        withAnimation {
            switch currentPage {
            case 1:
                // ─── snapshot page 1’s built rows ───────────────
                page1OptionsBackup = dropdownOptions
                
                // now move to page 2 and build its rows
                currentPage = 2
                setupPage2()
                
            case 2:
                // move to page 3 and build it once
                currentPage = 3
                if occasions.isEmpty {
                    setupPage3()
                }
                
            default: break
            }
            expandedIndex = nil
        }
    }
    
    func goBack() {
        withAnimation {
            switch currentPage {
            case 2:
                // ─── restore page 1’s snapshot ─────────────────
                currentPage       = 1
                dropdownOptions   = page1OptionsBackup
                
            case 3:
                // rebuild page 2’s static rows (keeps page2Selections!)
                currentPage = 2
                setupPage2()
                
            default: break
            }
            expandedIndex = nil
        }
    }
    
    
    
    // ─────────────────────────────────────────────────────────────────
    // Helpers for the dropdown bindings
    // ─────────────────────────────────────────────────────────────────
    var currentPlaceholders: [String] {
        if currentPage == 1 {
            return [
                "Select category",
                "Select kind",
                "Select subkind",
                "Select style",
            ]
        } else {
            return [
                "Select fabric",
                "Select secondary fabric",
                "Select colour"
            ]
        }
    }
    
    func selectionBinding(at idx: Int) -> Binding<String?> {
        Binding<String?>(
            get: {
                // pick the right array, then guard the index
                let selections = self.currentPage == 1
                ? self.page1Selections
                : self.page2Selections
                guard idx < selections.count else { return nil }
                return selections[idx]
            },
            set: { newValue in
                if self.currentPage == 1 {
                    guard idx < self.page1Selections.count else { return }
                    // clear downstream slots
                    for i in (idx+1)..<self.page1Selections.count {
                        self.page1Selections[i] = nil
                    }
                    self.page1Selections[idx] = newValue
                } else {
                    guard idx < self.page2Selections.count else { return }
                    self.page2Selections[idx] = newValue
                }
                self.selectionChanged(at: idx, to: newValue)
            }
        )
    }
    
    
    // ─────────────────────────────────────────────────────────────────
    // Page 1 dynamic dropdown logic
    // ─────────────────────────────────────────────────────────────────
    private func selectionChanged(at index: Int, to newValue: String?) {
        guard currentPage == 1 else { return }
        
        // 1) Trim off any deeper rows
        dropdownOptions = Array(dropdownOptions.prefix(index + 1))
        
        // 2) If they cleared the choice, stop here
        guard let choice = newValue else { return }
        
        // 3) Compute next options
        let next: [String]
        switch index {
        case 0:
            guard let cat = Category(rawValue: choice) else { return }
            switch cat {
            case .top:      next = topOptions.kindOptions
            case .bottom:   next = bottomOptions.kindOptions
            case .shoe:     next = shoeOptions.kindOptions
            case .onePiece: next = onePieceOptions.kindOptions
            }
            
        case 1:
            guard
                let catRaw = page1Selections[0],
                let cat    = Category(rawValue: catRaw)
            else { return }
            switch cat {
            case .top:
                next = topOptions.subkindOptions
            case .bottom:
                let key = bottomOptions.subkindMapping.keys
                    .first { choice.contains($0) } ?? ""
                next = bottomOptions.subkindMapping[key] ?? []
            case .shoe:
                next = shoeOptions.subkindOptions
            case .onePiece:
                next = onePieceOptions.subkindMapping[choice] ?? []
            }
            
        case 2:
            guard
                let catRaw = page1Selections[0],
                let cat    = Category(rawValue: catRaw)
            else { return }
            switch cat {
            case .top:      next = topOptions.styleOptions
            case .bottom:   next = bottomOptions.styleOptions
            case .shoe:     next = shoeOptions.styleOptions
            case .onePiece: next = onePieceOptions.finalOptions
            }
            
            
        default:
            return
        }
        
        // 4) Append the new row
        if !next.isEmpty {
            dropdownOptions.append(next)
        }
    }
    
    // ─────────────────────────────────────────────────────────────────
    // Page setup helpers
    // ─────────────────────────────────────────────────────────────────
    private func setupPage1() {
        dropdownOptions = [ Category.allCases.map(\.rawValue) ]
    }
    
    private func setupPage2() {
        let primaryFabrics   = allFabricOptions.fabrics.filter { $0 != "None" }
        let secondaryFabrics = allFabricOptions.fabrics
        let colours          = allColors.map(\.name)
        
        dropdownOptions = [
            primaryFabrics,
            secondaryFabrics,
            colours
        ]
    }
    
    // note: we clear selectedOccasions in goForward only once,
    // so setupPage3 just reloads the grid data
    private func setupPage3() {
        occasions = allOccasions
    }
    
    // MARK: – Submit
    
    @MainActor
    func submit() async {
        
        // 🐛 Debug: log your raw selections and UUID lookups
            let kindRaw  = page1Selections[1]    // index 1 always exists
            let subRaw   = page1Selections[2]
            let styleRaw = page1Selections[3]

            print("""
            🔍 About to submit:
              page1Selections = \(page1Selections)
              page2Selections = \(page2Selections)
              selectedOccasions = \(selectedOccasions)
              
              kindRaw  = \(String(describing: kindRaw))
              subRaw   = \(String(describing: subRaw))
              styleRaw = \(String(describing: styleRaw))

              kindUUID   = \(String(describing: kindRaw.flatMap { kindUUIDs[$0] }))
              subUUID    = \(String(describing: subRaw.flatMap { subkindUUIDs[$0] }))
              styleObj   = \(String(describing: styleRaw.flatMap { raw in allStyleUUID.first(where: { $0.name == raw }) }))
              
              primaryFabric = \(String(describing: page2Selections[0]))
              secondaryFabric = \(String(describing: page2Selections[1]))
              color = \(String(describing: page2Selections[2]))
              
              primaryFabricUUID = \(String(describing: page2Selections[0].flatMap { fab in allFabricUUID.first(where: { $0.name == fab }) }))
              secondaryFabricUUID = \(String(describing: page2Selections[1].flatMap { fab in allFabricUUID.first(where: { $0.name == fab }) }))
              colorUUID = \(String(describing: page2Selections[2].flatMap { col in allColorsUUID.first(where: { $0.name == col }) }))
            """)
            
            guard canSubmit else {
              print("⚠️ Form incomplete – cannot submit")
              return
            }
        
        isSubmitting = true
        defer { isSubmitting = false }

      
        
        
        // 0) quick guard against an empty form or missing image
        guard canSubmit else {
            print("⚠️ Form incomplete – cannot submit")
            return
        }
        guard
            let ui = selectedImage,
            let jpegData = ui.jpegData(compressionQuality: 0.8)
        else {
            print("⚠️ No image to upload")
            return
        }

        // 1) pick a UUID for this new item + its file name
        let wardrobeItemId = UUID()
        let fileName       = wardrobeItemId.uuidString + ".jpg"

        do {
            // 2) upload the image → public URL
            let imageURL = try await repo.uploadImage(
                data: jpegData,
                fileName: fileName,
                userID: userID
            )

            // ────────────────────────────────────────────────
            // 3a) Page 1: KIND / SUBKIND / STYLE (all required)
            //     (we don't actually need the raw "category" string)
            print("🔍 DEBUG: About to lookup UUIDs...")
            print("🔍 DEBUG: kindRaw = \(String(describing: page1Selections[1]))")
            print("🔍 DEBUG: subRaw = \(String(describing: page1Selections[2]))")
            print("🔍 DEBUG: styleRaw = \(String(describing: page1Selections[3]))")
            
            guard
                let kindRaw   = page1Selections[1],                // ← KIND lives at index 1
                let kindUUID  = kindUUIDs[kindRaw],

                let subRaw    = page1Selections[2],                // ← SUBKIND at index 2
                let subUUID   = subkindUUIDs[subRaw],

                let styleRaw  = page1Selections[3],                // ← STYLE at index 3
                let styleObj  = allStyleUUID.first(where: { $0.name == styleRaw })
            else {
                print("⚠️ Missing required Page 1 selection")
                print("⚠️ DEBUG: kindRaw=\(String(describing: page1Selections[1])), kindUUID=\(String(describing: page1Selections[1].flatMap { kindUUIDs[$0] }))")
                print("⚠️ DEBUG: subRaw=\(String(describing: page1Selections[2])), subUUID=\(String(describing: page1Selections[2].flatMap { subkindUUIDs[$0] }))")
                print("⚠️ DEBUG: styleRaw=\(String(describing: page1Selections[3])), styleObj=\(String(describing: page1Selections[3].flatMap { raw in allStyleUUID.first(where: { $0.name == raw }) }))")
                return
            }
            let kindId    = kindUUID.uuidString
            let subkindId = subUUID.uuidString
            let styleId   = styleObj.id.uuidString

        
            // ────────────────────────────────────────────────
            // 3b) Page 2: PRIMARY FABRIC / SECONDARY FABRIC / COLOUR (all required)
            guard
                let primRaw = page2Selections[0],
                let primObj = allFabricUUID.first(where: { $0.name == primRaw }),

                let secRaw  = page2Selections[1],
                let secObj  = allFabricUUID.first(where: { $0.name == secRaw }),

                let colRaw  = page2Selections[2],
                let colObj  = allColorsUUID.first(where: { $0.name == colRaw })
            else {
                print("⚠️ Missing fabric or colour selection")
                return
            }
            let primaryFabricId   = primObj.id.uuidString
            let secondaryFabricId = secObj.id.uuidString
            let colorId           = colObj.id.uuidString

            // ────────────────────────────────────────────────
            // 4) Build your JSON payload
            let payload = WardrobeItemPayload(
                wardrobe_item_id:  wardrobeItemId.uuidString,
                user_id:           userID,
                image:             imageURL,
                kind_id:           kindId,
                subkind_id:        subkindId,
                style_id:          styleId,
                primary_fabric_id: primaryFabricId,
                secondary_fabric_id: secondaryFabricId,
                color_id:          colorId
            )

            // 5) Gather occasion IDs
            let occasionIds = selectedOccasions
                .compactMap { occasionUUIDs[$0]?.uuidString }

            // — DEBUG: print the exact JSON you’re sending —
            do {
                let enc = JSONEncoder()
                enc.outputFormatting = [.sortedKeys, .prettyPrinted]
                let data = try enc.encode(payload)
                if let json = String(data: data, encoding: .utf8) {
                    print("📤 Upload payload JSON:\n\(json)")
                }
            } catch {
                print("⚠️ Failed to encode payload for debug:", error)
            }

            // 6) Create the wardrobe row
            try await repo.createItem(payload)

            // 7) Link the occasions in the join table
            try await repo.linkOccasions(
                occasionIds,
                forWardrobeItemID: wardrobeItemId.uuidString
            )

            print("✅ Successfully uploaded item and linked occasions!")

        } catch {
            print("❌ Failed to submit wardrobe item:", error)
        }
    }

}
