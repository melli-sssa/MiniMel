//
//  ItemUploadViewModel.swift
//  MiniMel
//
//  Created by Melissa Adesina on 23/03/2025.
//

import SwiftUI
import PhotosUI

class ItemUploadViewModel: ObservableObject {
    @Published var selectedItem: PhotosPickerItem?
    @Published var selectedImage: UIImage?
    @Published var shouldNavigateToDetails = false

    func handlePhotoPickerSelection(item: PhotosPickerItem) {
        Task {
            do {
                if let data = try await item.loadTransferable(type: Data.self) {
                    
                    print("🔍 Raw image data size: \(data.count) bytes")
                    
                    if let image = UIImage(data: data) {
                        print("🔍 UIImage created from raw data")
                        print("🔍 Original image size: \(image.size)")
                        print("🔍 Original image scale: \(image.scale)")
                        print("🔍 Original image orientation: \(image.imageOrientation.rawValue)")

                        // Debug print—make sure this shows up in console
                        print("🐣  Loaded image, navigating to details…")

                        // Now update state on the main thread
                        await MainActor.run {
                            self.selectedImage = image
                            self.shouldNavigateToDetails = true
                            
                            print("🔧 selectedImage set: \(self.selectedImage != nil)")
                            print("🔧 shouldNavigateToDetails set: \(self.shouldNavigateToDetails)")
                        }
                    } else {
                        print("⚠️ Failed to convert data to UIImage.")
                    }
                } else {
                    print("⚠️ Failed to load image data.")
                }
            } catch {
                print("❌ Error loading image: \(error)")
            }
        }
    }
}
