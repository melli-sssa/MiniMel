//
//  AuthModelView.swift
//  MiniMel
//

import Foundation
import Supabase

@MainActor // Ensures UI updates always happen on the main thread
class AuthViewModel: ObservableObject {
    
    @Published var email = ""
    @Published var password = ""
    @Published var confirmPassword = ""
    @Published var name = ""
    @Published var lastName = ""
    
    @Published var isLoading = false       // loading state while waiting for supaBase reponse
    @Published var isAuthenticated = false // determines weather to navigate to main app after login
    @Published var errorMessage: String?   // error handling. '?' as its optional
    @Published var successMessage: String? // if session is granted return succes. '?' optional as value can be nil
    
    /// The Supabase user's ID (UUID string) once they've signed in.
    @Published var userID: UUID?

    var userFirstName: String? {
        // For now, just return the local name since async access is complex
        return name.isEmpty ? nil : name
    }
    
    private let client = SupabaseClientManager.shared.getClient()
    // accessing the single instane of our supabse client stored in the 'shared' keyword.
    // client can only be accessed via the getClient() function as its private.
    
    
    // declaring our login function . compiler will read it to be asynchronous
    func login() async {
        isLoading = true // login is in progress so we start the login animation
        errorMessage = nil // clear any previous error message
        
        // 'do' blocks attempt operations that may fail. the catch block will catch and diplay these errors
        do {
            // removes network calls from the main thread using task
            let response = try await Task {
                // accessing the 'sign in ' function in the  authentication module within the supabase sdk
                return try await client.auth.signIn(
                    email: email,    // user inputs email & password and we 'await' a session
                    password: password
                )
            }.value
            
            // extract and store the user's ID
            let user = response.user
            self.userID = user.id
            
            self.isLoading = false
            isAuthenticated = true
            print("user logged in successfully : \(response )")
            
        }
        // 'catch' block will handle errors from the 'do' block
        catch {
            self.isLoading = false
            self.errorMessage = error.localizedDescription
            print(error.localizedDescription)
        }
    }
    
    
    
    func signUp() async {
        
        guard password == confirmPassword else {
            self.errorMessage = "Passwords do not match"
            return
        } // checking if password matched before proceeding with network request.
        
        self.isLoading = true
        errorMessage = nil
        
        do {
            let response = try await Task {
                return try await client.auth.signUp(
                    email: email,
                    password: password,
                    data: ["name": AnyJSON(name), "lastName": AnyJSON(lastName)]
                )
            }.value
           
            // extract and store the user's ID
            let user = response.user
            self.userID = user.id
            
            self.isLoading = false // if success is successful remove loading state
            print("User has signed up successfully.") // More meaningful message

            if response.session != nil {
                isAuthenticated = true  // Now the user is authenticated and redirected to the home page
                print("User is authenticated.") // Logs only what's needed
            }
            
        } catch {
            self.isLoading = false
            self.errorMessage = error.localizedDescription
            print(error.localizedDescription) // error handling
        }
    }
    
    func signOut() {
        Task {
            do {
                try await client.auth.signOut()
                await MainActor.run {
                    self.isAuthenticated = false
                    self.userID = nil
                    self.email = ""
                    self.password = ""
                    self.confirmPassword = ""
                    self.name = ""
                    self.lastName = ""
                    self.errorMessage = nil
                    self.successMessage = nil
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "Error signing out: \(error.localizedDescription)"
                }
            }
        }
    }
}

//EXCEPTION
//WHEN others THEN
//   RAISE WARNING 'Error inserting user: %', SQLERRM;
//   RETURN NEW;
