//
//  FavouritesViewModel.swift
//  MiniMel
//
//  Created by Melissa Adesina on 16/05/2025.
//
// FavoritesViewModel.swift
import Foundation
import SwiftUI

@MainActor
class FavoritesViewModel: ObservableObject {
    struct OutfitDisplay: Identifiable {
        let id: UUID 
        var top: WardrobeItemPayload?
        var bottom: WardrobeItemPayload?
        var onePiece: WardrobeItemPayload?
        var shoe: WardrobeItemPayload? 
    }

    @Published var outfits: [OutfitDisplay] = []
    private let repository = SupabaseWardrobeRepository()  
    private let userID: String

    init(userID: String) {
        self.userID = userID
    }

    func fetchSavedOutfits() async {
        do {
            let savedRows: [SavedOutfit] = try await repository.fetchSavedOutfits(for: userID)
            let allItems: [WardrobeItemPayload] = try await repository.fetchItems(for: userID, categoryID: nil)
            var displays: [OutfitDisplay] = []

            for row in savedRows {
                var d = OutfitDisplay(
                    id: row.id,            
                    top: nil,
                    bottom: nil,
                    onePiece: nil,
                    shoe: nil
                )
                if let topID = row.topId {
                    d.top = allItems.first { $0.wardrobe_item_id == topID }
                }
                if let bottomID = row.bottomId {
                    d.bottom = allItems.first { $0.wardrobe_item_id == bottomID }
                }
                if let oneID = row.onePieceId {
                    d.onePiece = allItems.first { $0.wardrobe_item_id == oneID }
                }
                d.shoe = allItems.first { $0.wardrobe_item_id == row.shoeId }
                
                if d.shoe == nil {
                    print("⚠️ Warning: Shoe with ID \(row.shoeId) for saved outfit \(row.id) not found in user's wardrobe items.")
                }

                displays.append(d)
            }
            self.outfits = displays
        } catch {
            print("Error fetching saved outfits: \(error)")
        }
    }

    func deleteSavedOutfit(outfitIdToDelete: UUID) async {
        do {
            try await repository.deleteSavedOutfit(outfitID: outfitIdToDelete)
            outfits.removeAll { $0.id == outfitIdToDelete }
            print("✅ Successfully deleted saved outfit \(outfitIdToDelete).")
        } catch {
            print("❌ Failed to delete saved outfit \(outfitIdToDelete): \(error)")
        }
    }
}
