//
//  GenerateOutfitViewModel.swift
//  MiniMel
//
//  Created by Melissa Adesina on 13/05/2025.
//

import Foundation
import Supabase

@MainActor
class GenerateOutfitViewModel: ObservableObject {
    // MARK: – Published state
    @Published var occasions: [OccasionRecord] = []
    @Published var selectedOccasion: OccasionRecord?
    @Published private(set) var outfits: [Outfit] = []
    @Published private(set) var currentIndex: Int = 0 {
        didSet {
            print("ℹ️ currentIndex changed to: \(currentIndex). Calling checkIfCurrentOutfitIsSaved().")
            checkIfCurrentOutfitIsSaved()
        }
    }
    @Published var errorMessage: String?
    @Published private(set) var savedOutfitsForUser: [SavedOutfit] = []
    @Published private(set) var isCurrentOutfitSaved: Bool = false
    
    // MARK: – Helpers
    private let repository = SupabaseWardrobeRepository.shared
    private let userID: String
    private let suggestions: [String: String] = [
        "Work (Corporate)":           "corporate attire, modest, smart dress",
        "Birthday Dinner (Glamorous)": "go glam—think heels, sparkle & elegance",
        "Aesthetic Brunch":           "soft tones, comfy layers, brunch chic",
        "Casual Shopping":            "easy pieces you can walk in",
        "Clubbing":                   "bold fits—leather, mesh, heels",
        "Work (Casual Stylish)":      "professional yet fashionable",
        "Activity Date":              "mix comfort with cute—easy to move in",
        "Birthday Party":             "bright colors, stylish outfits",
        "Travel":                     "practical layers & comfy shoes"
    ]
    
    // MARK: – Init
    init(userID: String) {
        self.userID = userID
        print("✨ GenerateOutfitViewModel initialized for userID: \(userID)")
        Task {
            await loadOccasions()
            await loadSavedOutfitsForCurrentUser()
        }
    }
    
    @MainActor
    private func loadOccasions() async {
        do {
            occasions = try await repository.fetchOccasions()
        } catch {
            errorMessage = "Couldn't load occasions: \(error.localizedDescription)"
        }
    }

    private func loadSavedOutfitsForCurrentUser() async {
        print("🔄 Loading saved outfits for user: \(userID)")
        do {
            savedOutfitsForUser = try await repository.fetchSavedOutfits(for: userID)
            print("✅ Loaded \(savedOutfitsForUser.count) saved outfits for user.")
            if savedOutfitsForUser.isEmpty {
                print("   The loaded list of saved outfits is empty.")
            } else {
                print("   Full list of loaded saved outfit IDs (outfit_id): \(savedOutfitsForUser.map { $0.id.uuidString })")
            }
            checkIfCurrentOutfitIsSaved()
        } catch {
            print("‼️ Error loading saved outfits for user: \(error.localizedDescription)")
            savedOutfitsForUser = []
            isCurrentOutfitSaved = false
        }
    }

    private func checkIfCurrentOutfitIsSaved() {
        guard !savedOutfitsForUser.isEmpty else {
            print("ℹ️ CHECK: No saved outfits currently loaded in `savedOutfitsForUser` (count: \(savedOutfitsForUser.count)). `isCurrentOutfitSaved` set to false.")
            isCurrentOutfitSaved = false
            return
        }
        guard let currentDisplayedOutfit = currentOutfit else {
            print("ℹ️ CHECK: No `currentOutfit` to check. `isCurrentOutfitSaved` set to false.")
            isCurrentOutfitSaved = false
            return
        }

        let currentTopId = currentDisplayedOutfit.top?.id.uuidString.uppercased()
        let currentBottomId = currentDisplayedOutfit.bottom?.id.uuidString.uppercased()
        let currentOnePieceId = currentDisplayedOutfit.onePiece?.id.uuidString.uppercased()
        let currentShoeId = currentDisplayedOutfit.shoe.id.uuidString.uppercased()

        print("🔍 CHECK: Checking if current displayed outfit is saved (normalized to UPPERCASE):")
        print("   Current Displayed Top ID: \(currentTopId ?? "nil")")
        print("   Current Displayed Bottom ID: \(currentBottomId ?? "nil")")
        print("   Current Displayed OnePiece ID: \(currentOnePieceId ?? "nil")")
        print("   Current Displayed Shoe ID: \(currentShoeId ?? "nil")")

        var matchFound = false
        for (index, previouslySavedOutfit) in savedOutfitsForUser.enumerated() {
            let savedTopId = previouslySavedOutfit.topId?.uppercased()
            let savedBottomId = previouslySavedOutfit.bottomId?.uppercased()
            let savedOnePieceId = previouslySavedOutfit.onePieceId?.uppercased()
            let savedShoeId = previouslySavedOutfit.shoeId.uppercased()

            print("   Comparing with saved_outfits[\(index)] (DB outfit_id: \(previouslySavedOutfit.id.uuidString)) (normalized to UPPERCASE):")
            print("     Saved DB Top ID:      \(savedTopId ?? "nil")")
            print("     Saved DB Bottom ID:   \(savedBottomId ?? "nil")")
            print("     Saved DB OnePiece ID: \(savedOnePieceId ?? "nil")")
            print("     Saved DB Shoe ID:     \(savedShoeId)")

            if savedTopId == currentTopId &&
               savedBottomId == currentBottomId &&
               savedOnePieceId == currentOnePieceId &&
               savedShoeId == currentShoeId {
                print("✅ MATCH FOUND with saved_outfits[\(index)]!")
                matchFound = true
                break
            }
        }
        
        if matchFound {
            print("👍 `isCurrentOutfitSaved` set to true.")
        } else {
            print("👎 No match found in `savedOutfitsForUser`. `isCurrentOutfitSaved` set to false.")
        }
        isCurrentOutfitSaved = matchFound
    }
        
    // MARK: – Bindings for the View
    var currentOutfit: Outfit? {
        guard outfits.indices.contains(currentIndex) else { return nil }
        return outfits[currentIndex]
    }
    
    var suggestionForOccasion: String {
        guard let name = selectedOccasion?.name else { return "" }
        return suggestions[name, default: "consider exploring new styles!"]
    }
    
    // MARK: – Generate logic
    @MainActor
    func selectOccasion(_ occasion: OccasionRecord) async {
        print("🌟 Occasion selected: \(occasion.name). Fetching items and generating outfits.")
        selectedOccasion = occasion
        errorMessage = nil

        if occasion.name.lowercased() == "travel" {
            await generateTravelOutfits(occasionID: occasion.id)
        } else {
            await generateRegularOutfits(occasionID: occasion.id)
        }
    }

    @MainActor
    private func generateTravelOutfits(occasionID: UUID) async {
        do {
            let detailedItems = try await repository.fetchItemsForOccasionWithDetails(
                userID: userID,
                occasionID: occasionID
            )
            print("   Fetched \(detailedItems.count) detailed items for Travel occasion.")

            let tops = detailedItems.filter { $0.kind.category.name.lowercased().contains("top") }
            let bottoms = detailedItems.filter { $0.kind.category.name.lowercased().contains("bottom") }
            let shoes = detailedItems.filter { $0.kind.category.name.lowercased().contains("shoe") }
            let onePieces = detailedItems.filter { $0.kind.category.name.lowercased().contains("one") }

            var missing: [String] = []
            if onePieces.isEmpty {
                if tops.isEmpty { missing.append("top") }
                if bottoms.isEmpty { missing.append("bottom") }
            }
            if shoes.isEmpty { missing.append("shoes") }

            guard missing.isEmpty else {
                let text: String = missing.count == 1 ? missing[0] : 
                                 missing.count == 2 ? missing.joined(separator: " and ") :
                                 missing.dropLast().joined(separator: ", ") + ", and " + missing.last!
                errorMessage = "You need at least one \(text) tagged \"Travel\" before I can build an outfit."
                outfits = []
                currentIndex = 0
                return
            }

            var detailedCombos: [DetailedOutfit] = []
            
            for top in tops {
                for bottom in bottoms {
                    for shoe in shoes {
                        detailedCombos.append(DetailedOutfit(
                            top: top,
                            bottom: bottom,
                            onePiece: nil,
                            shoe: shoe
                        ))
                    }
                }
            }
            
            for onePiece in onePieces {
                for shoe in shoes {
                    detailedCombos.append(DetailedOutfit(
                        top: nil,
                        bottom: nil,
                        onePiece: onePiece,
                        shoe: shoe
                    ))
                }
            }

            let travelPriorityOutfits = detailedCombos.filter { $0.meetsTravelCriteria }
            let otherOutfits = detailedCombos.filter { !$0.meetsTravelCriteria }
            
            print("   Travel priority outfits (Linen + Open-toe): \(travelPriorityOutfits.count)")
            print("   Other outfits: \(otherOutfits.count)")

            let prioritizedOutfits = travelPriorityOutfits.shuffled() + otherOutfits.shuffled()
            
            outfits = prioritizedOutfits.map { $0.asOutfit }
            currentIndex = 0
            
            print("   Generated \(outfits.count) travel outfits with styling rules applied.")
            
            if outfits.isEmpty {
                errorMessage = "Not enough items tagged \"Travel\" to create diverse outfits. Try adding more variety!"
            }
        } catch {
            print("‼️ Error generating travel outfits:", error)
            errorMessage = "❌ Error generating travel outfits: \(error.localizedDescription)"
            outfits = []
            currentIndex = 0
        }
    }

    @MainActor
    private func generateRegularOutfits(occasionID: UUID) async {
        do {
            let items = try await repository.fetchItemsForOccasion(
                userID: userID,
                occasionID: occasionID
            )
            print("   Fetched \(items.count) items for regular occasion.")

            let tops = items.filter { $0.kind.category.name.lowercased().contains("top") }
            let bottoms = items.filter { $0.kind.category.name.lowercased().contains("bottom") }
            let shoes = items.filter { $0.kind.category.name.lowercased().contains("shoe") }
            let onePieces = items.filter { $0.kind.category.name.lowercased().contains("one") }

            var missing: [String] = []
            if onePieces.isEmpty {
                if tops.isEmpty { missing.append("top") }
                if bottoms.isEmpty { missing.append("bottom") }
            }
            if shoes.isEmpty { missing.append("shoes") }

            guard missing.isEmpty else {
                let text: String = missing.count == 1 ? missing[0] : 
                                 missing.count == 2 ? missing.joined(separator: " and ") :
                                 missing.dropLast().joined(separator: ", ") + ", and " + missing.last!
                errorMessage = "You need at least one \(text) tagged \"\(selectedOccasion?.name ?? "this occasion")\" before I can build an outfit."
                outfits = []
                currentIndex = 0
                return
            }

            var combos: [Outfit] = []
            for top in tops {
                for bottom in bottoms {
                    for shoe in shoes {
                        combos.append(.init(top: top, bottom: bottom, onePiece: nil, shoe: shoe))
                    }
                }
            }
            for one in onePieces {
                for shoe in shoes {
                    combos.append(.init(top: nil, bottom: nil, onePiece: one, shoe: shoe))
                }
            }

            outfits = combos.shuffled()
            print("   Generated and shuffled \(outfits.count) regular outfits.")
            currentIndex = 0
            
            if outfits.isEmpty {
                errorMessage = "Not enough items tagged \"\(selectedOccasion?.name ?? "this occasion")\" to create diverse outfits. Try adding more variety!"
            }
        } catch {
            print("‼️ Error generating regular outfits:", error)
            errorMessage = "❌ Error generating regular outfits: \(error.localizedDescription)"
            outfits = []
            currentIndex = 0
        }
    }

    func shuffleOutfit() {
        outfits.shuffle()
        currentIndex = 0
    }
    
    func nextOutfit() {
        if currentIndex < outfits.count - 1 {
            currentIndex += 1
        }
    }
    
    func saveCurrentOutfit() async {
        guard
            let outfitToSave = currentOutfit,
            let selectedOccasion = selectedOccasion,
            let userUUID = UUID(uuidString: userID)
        else {
            errorMessage = "Cannot save outfit: missing current outfit, occasion, or user ID."
            print("‼️ SAVE: Guard failed. \(errorMessage!)")
            return
        }
        
        print("💾 SAVE: Attempting to save current outfit. isCurrentOutfitSaved = \(isCurrentOutfitSaved)")
        if isCurrentOutfitSaved {
            errorMessage = "This outfit is already saved."
            print("ℹ️ SAVE: Prevented save because isCurrentOutfitSaved was true.")
            return
        }
        
        let topIdToSave = outfitToSave.top?.id.uuidString
        let bottomIdToSave = outfitToSave.bottom?.id.uuidString
        let onePieceIdToSave = outfitToSave.onePiece?.id.uuidString
        let shoeIdToSave = outfitToSave.shoe.id.uuidString

        print("   Saving with Item IDs - Top: \(topIdToSave ?? "nil"), Bottom: \(bottomIdToSave ?? "nil"), OnePiece: \(onePieceIdToSave ?? "nil"), Shoe: \(shoeIdToSave)")
        
        let payload = SavedOutfit(
            id: UUID(),
            userId: userUUID,
            occasionId: selectedOccasion.id,
            topId: topIdToSave,
            bottomId: bottomIdToSave,
            shoeId: shoeIdToSave,
            onePieceId: onePieceIdToSave,
            savedAt: Date()
        )
        
        do {
            try await repository.saveOutfit(payload)
            print("✅ SAVE: Outfit saved successfully to DB. Reloading saved outfits for user.")
            await loadSavedOutfitsForCurrentUser()
        } catch {
            errorMessage = "❌ Error saving outfit: \(error.localizedDescription)"
            print("‼️ SAVE: DB save failed. \(errorMessage!)")
        }
    }
}
