//
//  WardrobeViewModel.swift
//  MiniMel
//
//  Created by Melissa Adesina on 18/03/2025.
//

import SwiftUI
import Combine

@MainActor
final class WardrobeViewModel: ObservableObject {
  // MARK: – Published state
  @Published var items: [ClothingItem] = []
  @Published var categories: [WardrobeCategory] = []
  @Published var selectedCategoryID: Int? = nil {
    didSet {
      Task { await loadItems(for: userID) }
    }
  }

  // MARK: – NEW: generated outfit
  @Published var generatedOutfit: [ClothingItem] = []

  // MARK: – Dependencies
  private let repo: WardrobeRepository
  private let userID: String

  // MARK: – Init
  init(
    repo: WardrobeRepository = SupabaseWardrobeRepository(),
    userID: String
  ) {
    self.repo   = repo
    self.userID = userID

    // load both once at start
    Task {
      await loadCategories()
      await loadItems(for: userID)
    }
  }

  // MARK: – Load categories for the picker
  func loadCategories() async {
    do {
      self.categories = try await repo.fetchCategories()
    } catch {
      print("❌ failed to load categories:", error)
    }
  }

  // MARK: – Load (and filter) items
  func loadItems(for userID: String) async {
    do {
      let payloads = try await repo.fetchItems(
        for: userID,
        categoryID: selectedCategoryID
      )
      self.items = payloads.compactMap(ClothingItem.init(payload:))
    } catch {
      print("❌ Failed to load wardrobe items:", error)
    }
  }

  func selectCategory(_ id: Int?) {
    selectedCategoryID = id
  }

  // MARK: – NEW: “shuffle” / generate an outfit
  ///
  /// Right now this just takes your loaded `items` array,
  /// shuffles it, and grabs the first N pieces. You can
  /// extend this to your real “one top + one bottom + one shoe” logic later.
  func generateOutfit(count: Int = 4) {
    guard !items.isEmpty else {
      generatedOutfit = []
      return
    }
    // shuffle and take up to `count` items
    generatedOutfit = Array(items.shuffled().prefix(count))
  }

  func deleteItem(_ itemToDelete: ClothingItem) async {
    let imageName = itemToDelete.id + ".jpg" 
    
    do {
      try await repo.deleteWardrobeItem(itemID: itemToDelete.id, imageName: imageName)
      // Refresh items after deletion
      await loadItems(for: userID) 
      print("✅ Successfully deleted item \(itemToDelete.id) and refreshed wardrobe.")
    } catch {
      print("❌ Failed to delete item \(itemToDelete.id): \(error)")
      // Optionally, publish an error message to be displayed in the UI
    }
  }
}
