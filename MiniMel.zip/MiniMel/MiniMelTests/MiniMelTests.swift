import XCTest
@testable import MiniMel // Ensure your app target is imported

final class MiniMelTests: XCTestCase {

    var addDetailsVM: AddDetailsViewModel!

    override func setUpWithError() throws {
        addDetailsVM = AddDetailsViewModel(userID: "testUserID")
    }

    override func tearDownWithError() throws {
        addDetailsVM = nil
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

    func testCategoryEnumRawValues() {
        XCTAssertEqual(Category.top.rawValue, "Top", "Raw value for .top should be 'Top'")
        XCTAssertEqual(Category.bottom.rawValue, "Bottom", "Raw value for .bottom should be 'Bottom'")
        XCTAssertEqual(Category.shoe.rawValue, "Shoe", "Raw value for .shoe should be 'Shoe'")
        XCTAssertEqual(Category.onePiece.rawValue, "One Piece", "Raw value for .onePiece should be 'One Piece'")
    }

    func testImageClassification_SkirtIsBottom() {
        // Note: Ensure "Screenshot 2025-05-27 at 19.03.49" (or your chosen image with its extension) 
        // is added to the MiniMelTests target.
        // This image is a skirt.
        let imageName = "Screenshot 2025-05-27 at 19.03.49" // UIImage(named:) can often infer common extensions like .png or .jpg
        guard let testImage = UIImage(named: imageName, in: Bundle(for: type(of: self)), compatibleWith: nil) else {
            XCTFail("Failed to load '\(imageName)' from the test bundle. Make sure it's added to the MiniMelTests target and the name (including extension if needed) is correct.")
            return
        }

        // Perform classification using the helper function
        let predictedCategory = classifyImage(testImage)

        // Assert that the model predicts "Bottom" for a skirt
        let expectedCategory = "Bottom" 
        XCTAssertEqual(predictedCategory, expectedCategory, "The model did not classify the skirt image as '\(expectedCategory)'. Predicted: \(predictedCategory ?? "nil")")
    }

    func testImageClassification_LatestImage() {
        let imageName = "Screenshot 2025-05-27 at 13.02.43.png" // User-specified image
        guard let testImage = UIImage(named: imageName, in: Bundle(for: type(of: self)), compatibleWith: nil) else {
            XCTFail("Failed to load '\(imageName)' from the test bundle. Make sure it's added to the MiniMelTests target and the name (including extension if needed) is correct.")
            return
        }

        // Perform classification
        let predictedCategory = classifyImage(testImage)

        // Print the prediction to the console
        print("🏷️ Latest Image ('\(imageName)') Predicted Category: \(predictedCategory)")

        // Basic assertion to ensure a prediction was made
        XCTAssertNotNil(predictedCategory, "The predicted category should not be nil.")
        // You can add more specific assertions later if you know what this image should be.
    }

    func testAddDetailsViewModel_CanSubmit_InitialState() {
        XCTAssertFalse(addDetailsVM.canSubmit, "ViewModel should not be submittable in its initial state.")
    }

    func testAddDetailsViewModel_CanSubmit_AllFieldsFilled() {
        addDetailsVM.page1Selections = ["Top", "T-Shirt", "Crew Neck", "Casual"] 
        addDetailsVM.page2Selections = ["Cotton", "None", "Blue"] 
        addDetailsVM.selectedOccasions = ["Casual Shopping"]
        XCTAssertTrue(addDetailsVM.canSubmit, "ViewModel should be submittable when all required fields are filled.")
    }

    func testAddDetailsViewModel_CanSubmit_MissingOccasions() {
        addDetailsVM.page1Selections = ["Top", "T-Shirt", "Crew Neck", "Casual"]
        addDetailsVM.page2Selections = ["Cotton", "None", "Blue"]
        addDetailsVM.selectedOccasions = []
        XCTAssertFalse(addDetailsVM.canSubmit, "ViewModel should not be submittable if occasions are missing.")
    }

    func testAddDetailsViewModel_CanSubmit_MissingPage1Selection() {
        addDetailsVM.page1Selections = ["Top", "T-Shirt", "Crew Neck", nil] 
        addDetailsVM.page2Selections = ["Cotton", "None", "Blue"]
        addDetailsVM.selectedOccasions = ["Casual Shopping"]
        XCTAssertFalse(addDetailsVM.canSubmit, "ViewModel should not be submittable if a page 1 selection is missing.")
    }

    func testAddDetailsViewModel_CanSubmit_MissingPage2Selection() {
        addDetailsVM.page1Selections = ["Top", "T-Shirt", "Crew Neck", "Casual"]
        addDetailsVM.page2Selections = ["Cotton", "None", nil] 
        addDetailsVM.selectedOccasions = ["Casual Shopping"]
        XCTAssertFalse(addDetailsVM.canSubmit, "ViewModel should not be submittable if a page 2 selection is missing.")
    }
}
